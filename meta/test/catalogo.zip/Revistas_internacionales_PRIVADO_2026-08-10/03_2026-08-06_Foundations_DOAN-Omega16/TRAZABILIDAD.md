
# Trazabilidad del envío

El portal SNAPP fija el Submission ID, versión v1.0, modelo single-anonymous y nombre exacto del manuscrito. El historial visual conservado demuestra el paso por technical check y la asignación de editor.

El DOCX de `01_MANUSCRITO_ENVIADO` corresponde al manuscrito identificado por el portal. La carta original no estaba montada en la sesión; se conserva una transcripción verificada y un marcador para incorporar el DOCX exacto desde el PC.
