
# Datos verificados en SNAPP

- Journal: Foundations of Physics.
- Article type: Research.
- Peer review type: Single anonymous.
- Submission ID: `1b2f6ecd-afe3-4786-81a7-e1789b3bcb3e`.
- Submission version: `v1.0`.
- Manuscript file: `Lloret_Egea_Juan_Antonio_DOAN_Omega16_Foundations_of_Physics.docx`.
- Cover letter: `02_Lloret_Egea_Juan_Antonio_DOAN_Omega16_Foundations_of_Physics_Cover_Letter.docx`.
- Received: 06/08/2026.
- Technical check: 06/08/2026.
- Technical check passed: 07/08/2026.
- Ready for editorial assignment: 07/08/2026.
- Editor assigned: 07/08/2026.
- Current state: With editor / You have an editor assessing your submission.
