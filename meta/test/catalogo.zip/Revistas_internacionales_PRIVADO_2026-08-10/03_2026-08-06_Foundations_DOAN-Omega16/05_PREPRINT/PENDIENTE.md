
# Preprint específico

Pendiente de depósito. Mantener fecha real y autonomía editorial del preprint del SV. La política de Springer Nature fue auditada como compatible con depósito durante el proceso editorial.
