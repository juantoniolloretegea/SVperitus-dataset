
Copiar desde el PC, si se desea integridad binaria completa:
`02_Lloret_Egea_Juan_Antonio_DOAN_Omega16_Foundations_of_Physics_Cover_Letter.docx`

La carta está verificada por el Review de SNAPP y se conserva aquí como transcripción de contenido.
