
# Archivo privado — Revistas internacionales

**Fecha de corte:** 10 de agosto de 2026, 10:45 (España peninsular).  
**Naturaleza:** archivo privado de control editorial y trazabilidad.  
**Destino previsto:** almacenamiento local del autor y copia privada en Google Drive.

Este directorio agrupa los seis envíos internacionales realizados entre el 3 y el 9 de agosto de 2026. No está concebido como índice público ni como escaparate editorial. Cada expediente conserva por separado:

- el manuscrito o paquete enviado cuando el archivo exacto está disponible;
- cartas, declaraciones y antecedentes comunicados;
- justificantes del portal y estados editoriales;
- preprints o identificadores cuando existen;
- material suplementario/código cuando procede;
- documentos de control interno claramente separados del fósil del envío.

## Clasificación documental

- **CONFIRMADO_ENVIADO**: el portal o el PDF de revisión identifica expresamente el archivo como parte del envío.
- **EVIDENCIA_PORTAL**: captura, PDF o correo que acredita fecha, ID, estado o lista de archivos.
- **FUENTE_EDITABLE_ASOCIADA**: fuente del manuscrito conservada localmente pero no acreditada como archivo cargado.
- **TRANSCRIPCION_VERIFICADA**: contenido recuperado de un archivo previamente conservado en la biblioteca documental; no sustituye al original binario.
- **PENDIENTE_ORIGINAL_PC**: el original existe o existió en el PC del autor, pero sus bytes no estaban disponibles en esta sesión al construir este archivo.
- **CONTROL_INTERNO**: auditorías, borradores, pruebas, capturas o documentos auxiliares que no deben confundirse con el paquete remitido.

## Regla de fósil documental

Lo archivado en `01_MANUSCRITO_ENVIADO` no se sustituye por revisiones posteriores. Si una revista solicita cambios, se abrirá una carpeta independiente `REVISION_R1`, `REVISION_R2`, etc.

## Preprints

Los preprints del SV se conservan como publicaciones autónomas. Se respeta siempre la fecha real de depósito. No se añaden leyendas editoriales innecesarias ni se convierte el preprint en una mera ficha de seguimiento de la revista, salvo obligación expresa de la política aplicable.

## Integridad

Cada expediente contiene un `MANIFEST_SHA256.txt` calculado sobre los archivos efectivamente incluidos en este paquete. Los originales que falten se enumeran expresamente y deben incorporarse desde el PC antes de considerar el expediente binariamente completo.
