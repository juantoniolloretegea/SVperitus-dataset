
# Control de preprints y cronología

Este documento no sustituye las políticas de las revistas; conserva la decisión operativa ya auditada.

- **Physics of the Dark Universe / Elsevier:** el depósito posterior del preprint es compatible con la política de compartición de preprints. Fuente oficial utilizada en la auditoría: https://www.elsevier.com/about/policies-and-standards/sharing
- **Foundations of Physics / Springer Nature:** la política de preprints permite su depósito durante el proceso editorial. Fuente: https://support.springernature.com/en/support/solutions/articles/6000258807-preprints
- **Astronomy & Astrophysics:** la guía admite depósito en servidores de preprints. Fuente: https://www.aanda.org/for-authors/author-information/author-guide
- **Proceedings A:** el preprint específico ya existía al enviar el manuscrito, DOI 10.21428/39829d0b.f0892864.
- **IEEE TSMC-S:** el preprint específico ya existía al enviar el manuscrito, DOI 10.21428/39829d0b.e5347310, y fue declarado en el expediente.
- **IEEE Technology and Society Magazine:** el trabajo previo relacionado fue declarado expresamente mediante `Previously-Published-Statement` y copia del artículo antecedente.

**Regla común:** fecha real, trazabilidad real y cero retrodatación. El preprint del SV no se trata como una simple copia administrativa del envío externo.
