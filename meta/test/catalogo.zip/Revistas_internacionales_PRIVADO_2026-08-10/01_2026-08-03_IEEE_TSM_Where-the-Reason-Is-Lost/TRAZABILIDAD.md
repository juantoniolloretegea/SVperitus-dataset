
# Trazabilidad del envío

El Reviewer PDF de Research Exchange enumera expresamente tres archivos para peer review:

1. `Lloret-Egea_TSM_commentary.pdf` — Main Document - PDF.
2. `Previously-Published-Statement.docx` — Previously Published - Statement.
3. `editorialia.com-A number with no recorded reason may end up deciding for a patient.pdf` — Previously Published - Files.

El panel actual de IEEE Author Portal fija:
- Manuscript ID: `TSM-Aug-26-COM-0119`.
- Fecha: 3 de agosto de 2026.
- Estado actual: `Under Review`.

`Lloret-Egea_TSM_commentary_SOURCE.docx` se conserva como fuente editable asociada, no como archivo acreditado por la lista de peer review. La cover letter se conserva como comunicación administrativa.
