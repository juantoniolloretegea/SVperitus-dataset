# Registro privado — IEEE Technology and Society Magazine

**Título exacto:** Where the Reason Is Lost: Four Points of Failure in the Record of AI-Assisted Decisions  
**Fecha de envío:** 2026-08-03  
**Tipo:** Commentary  
**Identificador principal:** TSM-Aug-26-COM-0119  
**Identificador técnico/secundario:** fbe5f83a-cdda-426a-96f6-9844be475ee6  
**Estado último documentado (corte 10/08/2026):** Under Review  
**Modelo de revisión:** No fijado por la evidencia archivada  
**Preprint / antecedente:** Antecedente relacionado: DOI 10.21428/39829d0b.55593db8  

## Nota de trazabilidad
El envío declaró y aportó el trabajo previo relacionado. La afiliación registrada fue «La Biblia de la IA – The Bible of AI».

## Regla documental
Los archivos de `01_MANUSCRITO_ENVIADO` sólo se consideran fósil exacto cuando están acreditados por el portal o por una lista de archivos del envío. Los derivados, fuentes editables no cargadas y transcripciones se mantienen fuera de esa carpeta o se marcan expresamente.

## Próxima actualización
Registrar únicamente cambios externos reales: asignación editorial, entrada a revisión, decisión, revisión solicitada, aceptación/rechazo, publicación, DOI de versión de registro o cambios del preprint.
