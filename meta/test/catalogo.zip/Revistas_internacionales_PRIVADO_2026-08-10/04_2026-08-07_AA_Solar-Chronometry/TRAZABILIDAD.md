
# Trazabilidad del envío

- Article reference: `aa62477-26`.
- NESTOR UUID: `4e7eda8343d64bc6aebc0b9877b8fce6`.
- El paquete descargado de A&A contiene exactamente:
  - `aa62477-26_cover_letter.pdf`
  - `j_a_ll_e_Endpoint and provenance compatibility in solar evolutionary chronom-etry.zip`
  - `aa62477-26_generated_rev0.pdf`
- El ZIP de fuentes contiene únicamente `main.tex` y `references.bib`.
- El correo de A&A confirma la recepción y la sección `9. The Sun and the Heliosphere`.
