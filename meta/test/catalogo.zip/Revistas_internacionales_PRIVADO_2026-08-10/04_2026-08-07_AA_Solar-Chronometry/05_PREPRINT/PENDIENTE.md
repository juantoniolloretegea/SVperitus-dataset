
# Preprint específico

Pendiente de depósito en ITVIA/PubPub. A&A permite el depósito del manuscrito en servidores de preprints; mantener fecha real y no confundir la publicación autónoma del SV con una segunda revista.
