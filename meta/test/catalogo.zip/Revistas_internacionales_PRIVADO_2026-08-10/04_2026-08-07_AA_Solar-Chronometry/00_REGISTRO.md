# Registro privado — Astronomy & Astrophysics

**Título exacto:** Endpoint and provenance compatibility in solar evolutionary chronometry: A reproducible criterion for combining present-age anchors and future evolutionary boundaries  
**Fecha de envío:** 2026-08-07  
**Tipo:** Regular Paper  
**Identificador principal:** aa62477-26  
**Identificador técnico/secundario:** NESTOR UUID 4e7eda8343d64bc6aebc0b9877b8fce6  
**Estado último documentado (corte 10/08/2026):** Received by A&A; assigned for editorial handling (latest documented)  
**Modelo de revisión:** No fijado aquí  
**Preprint / antecedente:** Preprint específico posterior al envío: pendiente  

## Nota de trazabilidad
Sección confirmada: 9. The Sun and the Heliosphere. Paquete fuente exacto: main.tex + references.bib.

## Regla documental
Los archivos de `01_MANUSCRITO_ENVIADO` sólo se consideran fósil exacto cuando están acreditados por el portal o por una lista de archivos del envío. Los derivados, fuentes editables no cargadas y transcripciones se mantienen fuera de esa carpeta o se marcan expresamente.

## Próxima actualización
Registrar únicamente cambios externos reales: asignación editorial, entrada a revisión, decisión, revisión solicitada, aceptación/rechazo, publicación, DOI de versión de registro o cambios del preprint.
