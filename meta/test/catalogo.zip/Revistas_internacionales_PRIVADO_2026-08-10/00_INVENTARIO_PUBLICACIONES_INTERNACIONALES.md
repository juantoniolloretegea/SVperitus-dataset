# Inventario privado — Publicaciones en revistas internacionales

**Corte documental: 10 de agosto de 2026, 10:45 (España peninsular).**

## 1. IEEE Technology and Society Magazine
- **Título:** Where the Reason Is Lost: Four Points of Failure in the Record of AI-Assisted Decisions
- **Enviado:** 2026-08-03
- **Tipo:** Commentary
- **ID principal:** TSM-Aug-26-COM-0119
- **ID técnico/secundario:** fbe5f83a-cdda-426a-96f6-9844be475ee6
- **Estado:** Under Review
- **Revisión:** No fijado por la evidencia archivada
- **Preprint/antecedente:** Antecedente relacionado: DOI 10.21428/39829d0b.55593db8
- **Carpeta:** `01_2026-08-03_IEEE_TSM_Where-the-Reason-Is-Lost`
- **Control:** El envío declaró y aportó el trabajo previo relacionado. La afiliación registrada fue «La Biblia de la IA – The Bible of AI».

## 2. Physics of the Dark Universe
- **Título:** Curvature Without Substance and Gravitational Excess Without Matter: Two Theorems on a Declared Observable Domain
- **Enviado:** 2026-08-05
- **Tipo:** Full Length Article
- **ID principal:** DARK-D-26-01421
- **ID técnico/secundario:** —
- **Estado:** With Editor (status date 2026-08-06)
- **Revisión:** No registrado de forma concluyente en este archivo
- **Preprint/antecedente:** Preprint específico posterior al envío: pendiente
- **Carpeta:** `02_2026-08-05_PDU_Curvature-Without-Substance`
- **Control:** Vía subscription. Editorial Manager conserva Reviewer PDF con manuscrito, carta/declaraciones y suplementarios. Highlights preparado; carga exacta no certificada en la evidencia disponible.

## 3. Foundations of Physics
- **Título:** Nodal-Etary Transduction in Cosmology: DOAN-Ω16 (Lanzadera Ómicron) and the Boundary Coordinate of the Observable Universe
- **Enviado:** 2026-08-06
- **Tipo:** Research
- **ID principal:** 1b2f6ecd-afe3-4786-81a7-e1789b3bcb3e
- **ID técnico/secundario:** Submission version v1.0
- **Estado:** With Editor; technical check passed and editor assigned 2026-08-07
- **Revisión:** Single anonymous
- **Preprint/antecedente:** Preprint específico posterior al envío: pendiente
- **Carpeta:** `03_2026-08-06_Foundations_DOAN-Omega16`
- **Control:** SNAPP muestra que el manuscrito superó verificación técnica antes de la asignación editorial.

## 4. Astronomy & Astrophysics
- **Título:** Endpoint and provenance compatibility in solar evolutionary chronometry: A reproducible criterion for combining present-age anchors and future evolutionary boundaries
- **Enviado:** 2026-08-07
- **Tipo:** Regular Paper
- **ID principal:** aa62477-26
- **ID técnico/secundario:** NESTOR UUID 4e7eda8343d64bc6aebc0b9877b8fce6
- **Estado:** Received by A&A; assigned for editorial handling (latest documented)
- **Revisión:** No fijado aquí
- **Preprint/antecedente:** Preprint específico posterior al envío: pendiente
- **Carpeta:** `04_2026-08-07_AA_Solar-Chronometry`
- **Control:** Sección confirmada: 9. The Sun and the Heliosphere. Paquete fuente exacto: main.tex + references.bib.

## 5. Proceedings of the Royal Society A
- **Título:** Certified non-closure in finite resolution systems: operational certificates, conservative morphisms and revision complexity
- **Enviado:** 2026-08-08
- **Tipo:** Research
- **ID principal:** RSPA-2026-0829
- **ID técnico/secundario:** —
- **Estado:** Awaiting Admin Processing; ADM: Not Assigned
- **Revisión:** No necesario para el control actual
- **Preprint/antecedente:** DOI 10.21428/39829d0b.f0892864 — publicado 2026-08-08 antes del envío
- **Carpeta:** `05_2026-08-08_ProceedingsA_Certified-Non-Closure`
- **Control:** ScholarOne identifica un único PDF como File 1. El Reviewer Proof final acredita manuscrito, declaraciones e ID.

## 6. IEEE Transactions on Systems, Man, and Cybernetics: Systems
- **Título:** Exact Orientation Under Heterogeneous Interfaces: Episode Constitution and Closure-Preserving Substitution
- **Enviado:** 2026-08-09
- **Tipo:** Regular Paper
- **ID principal:** SMCA-26-08-4316
- **ID técnico/secundario:** —
- **Estado:** Under Review
- **Revisión:** Double anonymous
- **Preprint/antecedente:** DOI 10.21428/39829d0b.e5347310 — publicado 2026-08-09 y declarado
- **Carpeta:** `06_2026-08-09_IEEE_TSMCS_Exact-Orientation`
- **Control:** Final Review acredita Main LaTeX + PDF anónimos, Title Page, declaración y siete archivos previos, cover letter y código asociado.
