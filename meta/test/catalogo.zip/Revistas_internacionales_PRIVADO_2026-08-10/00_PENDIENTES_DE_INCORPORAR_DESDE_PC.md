
# Pendientes de incorporar desde el PC del autor

El archivo es ya funcional y trazable, pero algunos **originales binarios** previamente verificados no estaban montados en la sesión de trabajo. No se han falsificado ni recreado como si fueran originales.

## Physics of the Dark Universe
Conviene incorporar, si se conservan:
- `Lloret-Egea_PDU_Highlights.docx`
- `Lloret-Egea_PDU_Cover_Letter.docx`
- `Lloret-Egea_PDU_Declaration_of_Competing_Interests.docx`
- `Lloret-Egea_PDU_Numerical_Reproduction.py`
- `Lloret-Egea_PDU_Numerical_Reproduction_Output.txt`

El Reviewer PDF de Editorial Manager preservado en el expediente acredita el contenido remitido y contiene los suplementarios, pero no sustituye a esos originales binarios.

## Foundations of Physics
Conviene incorporar:
- `02_Lloret_Egea_Juan_Antonio_DOAN_Omega16_Foundations_of_Physics_Cover_Letter.docx`
- el PDF de revisión de SNAPP (`Review _ Foundations of Physics.pdf`), si se conserva localmente.

Se incluye una transcripción verificada de la carta y capturas actuales del portal.

## Proceedings of the Royal Society A
Conviene incorporar:
- `Certified_nonclosure_ProceedingsA_JALE.pdf` — archivo exacto identificado por ScholarOne como `File 1`.
- `Cover_letter_ProceedingsA.txt` — original local, si se desea conservar los mismos bytes.
- la impresión exacta de `Submission Confirmation`, si se conserva.

El Reviewer Proof final con `RSPA-2026-0829` preserva íntegramente el manuscrito recibido por ScholarOne.

## IEEE TSMC-S
El expediente conserva el paquete de envío, el Final Review y el Reviewer PDF combinado. Los siete PDFs individuales de antecedentes declarados no estaban todos disponibles como binarios separados; el Reviewer PDF combinado y el Final Review acreditan sus nombres y contenido. Si se conservan en el PC, pueden añadirse a `03_ANTECEDENTES_DECLARADOS/ORIGINALES_INDIVIDUALES/`.

## Regla
Cuando se incorpore cualquiera de estos originales, recalcular el `MANIFEST_SHA256.txt` del expediente y el manifiesto maestro.
