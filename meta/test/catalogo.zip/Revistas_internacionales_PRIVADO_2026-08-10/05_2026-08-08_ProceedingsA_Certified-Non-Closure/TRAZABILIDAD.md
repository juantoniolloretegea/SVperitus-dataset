
# Trazabilidad del envío

- Manuscript ID: `RSPA-2026-0829`.
- Fecha enviada: 08/08/2026.
- Estado actual: `Awaiting Admin Processing`; `ADM: Not Assigned`.
- ScholarOne identifica un único PDF como File 1: `Certified_nonclosure_ProceedingsA_JALE.pdf`.
- La cover letter se introdujo en el campo administrativo correspondiente, no como segundo archivo de Step 2.
- El Reviewer Proof final incluye ficha, declaraciones, manuscrito, preprint disclosure y bibliografía.
