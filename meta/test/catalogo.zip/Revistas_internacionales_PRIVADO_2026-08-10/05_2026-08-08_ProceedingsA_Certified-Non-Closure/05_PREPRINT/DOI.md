
# Preprint

DOI: https://doi.org/10.21428/39829d0b.f0892864  
Fecha pública: 8 de agosto de 2026.  
El Reviewer Proof incorpora la declaración de este preprint.
