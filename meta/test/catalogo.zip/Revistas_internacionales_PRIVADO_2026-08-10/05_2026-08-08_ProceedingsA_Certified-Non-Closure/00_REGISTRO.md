# Registro privado — Proceedings of the Royal Society A

**Título exacto:** Certified non-closure in finite resolution systems: operational certificates, conservative morphisms and revision complexity  
**Fecha de envío:** 2026-08-08  
**Tipo:** Research  
**Identificador principal:** RSPA-2026-0829  
**Identificador técnico/secundario:** —  
**Estado último documentado (corte 10/08/2026):** Awaiting Admin Processing; ADM: Not Assigned  
**Modelo de revisión:** No necesario para el control actual  
**Preprint / antecedente:** DOI 10.21428/39829d0b.f0892864 — publicado 2026-08-08 antes del envío  

## Nota de trazabilidad
ScholarOne identifica un único PDF como File 1. El Reviewer Proof final acredita manuscrito, declaraciones e ID.

## Regla documental
Los archivos de `01_MANUSCRITO_ENVIADO` sólo se consideran fósil exacto cuando están acreditados por el portal o por una lista de archivos del envío. Los derivados, fuentes editables no cargadas y transcripciones se mantienen fuera de esa carpeta o se marcan expresamente.

## Próxima actualización
Registrar únicamente cambios externos reales: asignación editorial, entrada a revisión, decisión, revisión solicitada, aceptación/rechazo, publicación, DOI de versión de registro o cambios del preprint.
