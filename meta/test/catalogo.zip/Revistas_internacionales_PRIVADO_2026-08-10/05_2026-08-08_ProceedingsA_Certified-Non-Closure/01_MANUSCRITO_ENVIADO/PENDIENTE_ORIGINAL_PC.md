
# Original exacto pendiente de copiar

ScholarOne acredita que el archivo de manuscrito cargado como `File 1` fue:

`Certified_nonclosure_ProceedingsA_JALE.pdf`

El original existe en el PC del autor según la captura archivada, pero sus bytes no estaban montados en esta sesión. El `Reviewer_Proof_RSPA-2026-0829.pdf` conserva íntegramente el manuscrito recibido y las declaraciones del portal.
