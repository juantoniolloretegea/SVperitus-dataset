
# Preprint específico

Pendiente de generar en ITVIA/PubPub con fecha real de depósito. El preprint será una publicación autónoma del SV; la situación editorial de PDU se archivará aquí, no se convertirá en el eje de presentación pública del preprint.
