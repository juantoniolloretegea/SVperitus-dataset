
# Trazabilidad del envío

- Manuscript ID: `DARK-D-26-01421`.
- Fecha inicial: 05/08/2026.
- Estado actual: `With Editor`; fecha de estado 06/08/2026.
- Manuscrito fuente disponible: `Lloret-Egea_PDU_Manuscript_v1_0.docx`.
- El Reviewer PDF de Editorial Manager conserva el conjunto remitido y los dos suplementarios.
- La pantalla actual del portal acredita el estado `With Editor`.
- El control de referencias mostró 10/15 referencias validadas automáticamente y 5 no enlazadas; se conserva sólo como dato del comprobador automático, no como defecto atribuido a los DOI del SV.
