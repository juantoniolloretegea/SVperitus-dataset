
# Suplementarios

Editorial Manager preserva en el Reviewer PDF el código y la salida remitidos. Para conservar los bytes originales, copiar desde el PC:

- `Lloret-Egea_PDU_Numerical_Reproduction.py`
- `Lloret-Egea_PDU_Numerical_Reproduction_Output.txt`
