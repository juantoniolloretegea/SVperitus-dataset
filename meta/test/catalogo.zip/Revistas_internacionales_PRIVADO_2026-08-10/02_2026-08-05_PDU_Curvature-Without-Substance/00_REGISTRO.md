# Registro privado — Physics of the Dark Universe

**Título exacto:** Curvature Without Substance and Gravitational Excess Without Matter: Two Theorems on a Declared Observable Domain  
**Fecha de envío:** 2026-08-05  
**Tipo:** Full Length Article  
**Identificador principal:** DARK-D-26-01421  
**Identificador técnico/secundario:** —  
**Estado último documentado (corte 10/08/2026):** With Editor (status date 2026-08-06)  
**Modelo de revisión:** No registrado de forma concluyente en este archivo  
**Preprint / antecedente:** Preprint específico posterior al envío: pendiente  

## Nota de trazabilidad
Vía subscription. Editorial Manager conserva Reviewer PDF con manuscrito, carta/declaraciones y suplementarios. Highlights preparado; carga exacta no certificada en la evidencia disponible.

## Regla documental
Los archivos de `01_MANUSCRITO_ENVIADO` sólo se consideran fósil exacto cuando están acreditados por el portal o por una lista de archivos del envío. Los derivados, fuentes editables no cargadas y transcripciones se mantienen fuera de esa carpeta o se marcan expresamente.

## Próxima actualización
Registrar únicamente cambios externos reales: asignación editorial, entrada a revisión, decisión, revisión solicitada, aceptación/rechazo, publicación, DOI de versión de registro o cambios del preprint.
