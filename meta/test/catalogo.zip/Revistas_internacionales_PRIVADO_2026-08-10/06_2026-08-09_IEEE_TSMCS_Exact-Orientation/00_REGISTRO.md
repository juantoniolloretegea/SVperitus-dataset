# Registro privado — IEEE Transactions on Systems, Man, and Cybernetics: Systems

**Título exacto:** Exact Orientation Under Heterogeneous Interfaces: Episode Constitution and Closure-Preserving Substitution  
**Fecha de envío:** 2026-08-09  
**Tipo:** Regular Paper  
**Identificador principal:** SMCA-26-08-4316  
**Identificador técnico/secundario:** —  
**Estado último documentado (corte 10/08/2026):** Under Review  
**Modelo de revisión:** Double anonymous  
**Preprint / antecedente:** DOI 10.21428/39829d0b.e5347310 — publicado 2026-08-09 y declarado  

## Nota de trazabilidad
Final Review acredita Main LaTeX + PDF anónimos, Title Page, declaración y siete archivos previos, cover letter y código asociado.

## Regla documental
Los archivos de `01_MANUSCRITO_ENVIADO` sólo se consideran fósil exacto cuando están acreditados por el portal o por una lista de archivos del envío. Los derivados, fuentes editables no cargadas y transcripciones se mantienen fuera de esa carpeta o se marcan expresamente.

## Próxima actualización
Registrar únicamente cambios externos reales: asignación editorial, entrada a revisión, decisión, revisión solicitada, aceptación/rechazo, publicación, DOI de versión de registro o cambios del preprint.
