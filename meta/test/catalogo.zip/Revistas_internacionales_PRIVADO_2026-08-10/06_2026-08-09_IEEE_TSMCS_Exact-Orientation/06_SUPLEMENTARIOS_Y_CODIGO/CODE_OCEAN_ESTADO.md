
# Code Ocean

Cápsula asociada al verificador determinista.  
DOI provisional comunicado por Code Ocean: `10.24433/CO.5971538.v1`.

En el último estado documentado, la cápsula había sido enviada para verificación/publicación. Hasta recibir confirmación definitiva, el DOI se conserva como provisional en este archivo privado.
