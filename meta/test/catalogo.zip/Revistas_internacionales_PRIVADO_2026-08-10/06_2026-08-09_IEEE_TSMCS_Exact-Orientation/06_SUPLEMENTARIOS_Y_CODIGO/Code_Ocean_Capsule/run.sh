#!/usr/bin/env bash
set -euo pipefail
mkdir -p /results
python3 /code/supplementary_verifier.py | tee /results/verification_output.txt
