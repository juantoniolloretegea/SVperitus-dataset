
# Trazabilidad del envío

El Final Review de IEEE acredita expresamente:

- `Main_Manuscript_LaTeX_ANONYMOUS.zip`
- `Main_Manuscript_PDF_ANONYMOUS.pdf`
- `Exact_Orientation_IEEE_TSMCS_Title_Page.docx`
- `Exact_Orientation_IEEE_TSMCS_Previously_Published_Statement.docx`
- siete PDFs de material previo
- `Exact_Orientation_IEEE_TSMCS_Cover_Letter.docx`

También acredita:
- respuesta «Yes» a material previamente presentado/publicado;
- código asociado;
- ausencia de datos;
- tres keywords: Decision-making, Finite state machines, Systems engineering.

El portal actual fija `SMCA-26-08-4316` y estado `Under Review`. El correo inicial conserva la fase de pre-screening y las condiciones de cargos por exceso de páginas.
