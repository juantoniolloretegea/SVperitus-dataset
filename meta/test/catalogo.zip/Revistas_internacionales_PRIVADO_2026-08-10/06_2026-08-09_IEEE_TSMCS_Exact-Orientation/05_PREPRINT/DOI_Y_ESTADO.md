
# Preprint específico

Título español: **Orientación exacta con interfaces heterogéneas: constitución del episodio y sustitución que preserva la clausura**  
DOI: https://doi.org/10.21428/39829d0b.e5347310  
Fecha pública: 9 de agosto de 2026.

Tras el envío se incorporó al preprint el aviso requerido por IEEE en inglés y traducción española. El preprint sigue siendo una publicación autónoma del SV.
