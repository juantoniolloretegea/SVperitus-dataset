# ACTA PRIVADA DE CIERRE DE R0-8
## Medición basal nativa reproducible del camino soberano

**Fecha:** 24/08/2026  
**Naturaleza:** PRIVADA · NO PUBLICAR  
**Proyecto:** SV — Lenguaje de Computación  
**Sec.6:** ABIERTA  
**R0:** ABIERTO  
**R0-8:** CERRADO · INTEGRADO  
**R1–R4:** NO INICIADOS  
**Garantía I:** NO_PROBADO  
**Garantía II:** NO_PROBADO  

---

## 1. Autoridad de cierre

Por decisión humana expresa de 24/08/2026 se autoriza el cierre e integración de R0-8 condicionado a que la revisión adversarial propia no detecte necesidad de mejorar el rendimiento antes de congelar la baseline.

La revisión adversarial propia concluye que **no existe bloqueante material ni recomendación de optimización previa al cierre**. La finalidad de R0-8 es fijar el coste basal del camino soberano antes de optimización; modificar el núcleo para mejorar cifras antes de cerrar esta baseline destruiría precisamente el valor comparativo de la medición.

---

## 2. Corte exacto

```text
repo =
juantoniolloretegea/SV-lenguaje-de-computacion

base main pre-R0-8 =
9e670f1dbf4c7eb497dfa9755e86e324d1cca102

rama =
r0-8-medicion-basal-nativa-2026-08-24

head R0-8 auditado y medido =
fb40acc713bb96a7576a3ab0fcc050b31f6d219c

merge virtual PR #21 medido =
ad6611ae848d2e04bd0dbcc32007d35c6b16c3a8

merge real / nuevo main =
acff3fb6555a99ab9536ea64c57af58e8d670f9a
```

El merge real tiene como padres:

```text
9e670f1dbf4c7eb497dfa9755e86e324d1cca102
fb40acc713bb96a7576a3ab0fcc050b31f6d219c
```

La comparación entre el merge virtual medido y el merge real devuelve:

```text
status = diverged
ahead_by = 1
behind_by = 1
files = []
```

Por tanto, la diferencia es genealógica/registral y no de contenido de árbol.

---

## 3. SUT cerrado

La baseline se refiere al camino nativo real:

```text
archivo .svp
→ sv-native release
→ sv_core
→ análisis
→ bienformación
→ constitución IR
→ proyección/salida observable del adaptador
```

No se utilizaron como sustituto:

```text
micropruebas de Tri
IrProgram fabricado a mano
Python como motor semántico
tiempo de navegador
estructuras sintéticas fuera del camino .svp
```

Python actuó únicamente como orquestador metrológico externo y lanzador del proceso.

---

## 4. Identidad del binario

Los dos intentos independientes preservados construyeron el mismo binario:

```text
perfil = release
bytes = 876616
SHA-256 =
734027dbd1cf59e7489259b5d728574168739f9730f2ef34678265e104be0f23

Rust = 1.98.0
Cargo = 1.98.0
```

---

## 5. Entorno y reproducibilidad

Perfil de CI fijado:

```text
runner = ubuntu-24.04
arquitectura = x86_64
Rust/Cargo = 1.98.0
```

La infraestructura asignó CPUs distintas a dos intentos:

```text
intento 1 = AMD EPYC 9V74 80-Core Processor
intento 2 = AMD EPYC 7763 64-Core Processor
```

La variación observada entre hospedadores queda registrada y no se transforma en una cifra universal del Lenguaje.

La baseline se interpreta como:

```text
baseline =
(binario SHA
 + head
 + perfil
 + CPU
 + toolchain
 + protocolo
 + corpus)
```

y no como una latencia intrínseca universal del SV.

---

## 6. Baseline del corpus válido

En el corpus válido comprometido, con ejecución nativa de proceso completo:

```text
intento 1:
medianas por caso ≈ 0,905–1,080 ms
mediana de medianas ≈ 0,943 ms
RSS mediana por caso ≈ 2,285–2,434 MiB

intento 2:
medianas por caso ≈ 0,824–0,988 ms
mediana de medianas ≈ 0,876 ms
RSS mediana por caso ≈ 2,293–2,406 MiB
```

La variación entre intentos es compatible con la diferencia de CPU asignada y no corresponde a cambio de binario ni de protocolo.

---

## 7. N01 — Nat

Escalas ejercidas:

```text
1
10
100
1000
5000 dígitos
```

No aparece crecimiento material abrupto en el intervalo.

**Límite R8-B:** el coste fijo de crear el proceso domina la medición y no permite resolver con precisión el coste marginal de Nat. R0-8 no acredita una ley asintótica ni una pendiente universal por dígito.

---

## 8. N02 — cardinalidad IR

Escalas ejercidas:

```text
1
10
50
100
500 objetos
```

En los dos intentos se observa crecimiento aproximadamente lineal en el intervalo medido, sin amplificación abrupta.

La prueba utiliza declaraciones semánticamente mínimas como eje controlado de cardinalidad y no representa una carga de trabajo universal o sectorial del Lenguaje.

---

## 9. N02 — longitud de identificador

Escalas ejercidas:

```text
8
64
256
1024
4096 caracteres
```

No aparece amplificación material grave.

El coste fijo domina en el intervalo; no se acredita una ley marginal o asintótica de coste por carácter.

---

## 10. N03 — Frame

Escalas ejercidas:

```text
1
10
50
100
250 nodos/estados
```

La familia entra por el mismo camino soberano `.svp` y ejerce constitución de `Frame`.

En el intervalo medido se observa crecimiento aproximadamente lineal:

```text
~0,85–0,93 ms en 1 nodo
~3,42–3,72 ms en 250 nodos
RSS ≈ 3,27–3,31 MiB en 250 nodos
```

No aparece amplificación catastrófica.

La curva mide el camino completo y no el coste aislado de `BTreeSet` ni de otra estructura interna.

---

## 11. Dictamen adversarial sobre la necesidad de optimizar

La adversarial propia buscó específicamente:

```text
latencia extrema anómala
RSS desproporcionado
crecimiento superlineal visible
amplificación brusca
inestabilidad entre ejecuciones
dependencia del orquestador Python
regresión semántica
necesidad de mejorar antes de congelar baseline
```

Resultado:

```text
latencia anómala = NO HALLAZGO
RSS anómalo = NO HALLAZGO
amplificación brusca N01–N03 = NO HALLAZGO
inestabilidad de binario = NO
regresión R0-7 = NO
dependencia semántica Python = NO
optimización previa necesaria = NO
```

Las cifras son materialmente compatibles con una primera realización soberana en esta fase y no constituyen un bloqueo para continuar.

Esta valoración **no compara** al SV con un lenguaje externo ni declara superioridad de rendimiento; afirma únicamente que los valores y tendencias observados no justifican una intervención de rendimiento antes de fijar la baseline.

---

## 12. Revisión adversarial independiente

La revisión independiente del candidato concluyó:

```text
SUT y camino R0-7 = ACREDITABLES
instrumentación = sin contaminación semántica evidenciada
N01–N03 = ejercidos
identidad de binario/heads = sólida
bloqueante material grave = no encontrado
inflación a WASM/G-I/G-II/R1 = no encontrada
R0-8 = cerrable con límites explícitos
```

Los límites obligatorios aceptados son:

```text
R8-A:
la baseline primaria mide el proceso real extremo a extremo;
no acredita desglose independiente parse / wellformed / lower / proyección.

R8-B:
N01 y longitud de identificadores están cuantificados como experimento,
pero no acreditan ley marginal o asintótica porque domina el coste fijo.
```

---

## 13. Evidencia preservada

Se preservaron dos intentos completos con el mismo binario y protocolo, incluyendo:

```text
baseline-native.json
scale-native.json
20 fuentes .svp generadas de escala
sv-native release
Cargo.lock
huellas y tamaño del binario
identidad Git de source/base/checkout
toolchain
entorno
datos crudos y agregados
```

Artefactos privados previos:

```text
PUNTO_PRIVADO_R0_8_CANDIDATO_ADVERSARIAL_MEDICION_BASAL_NATIVA_SV_2026-08-24.md
PAQUETE_PRIVADO_R0_8_CANDIDATO_ADVERSARIAL_SV_2026-08-24.zip
```

---

## 14. Integración

PR #21 quedó fusionado mediante merge ordinario con protección del `head` esperado:

```text
expected head =
fb40acc713bb96a7576a3ab0fcc050b31f6d219c

merge =
acff3fb6555a99ab9536ea64c57af58e8d670f9a
```

`main` fue verificado en el SHA de integración.

---

## 15. No efectos

El cierre de R0-8 no acredita ni abre automáticamente:

```text
paridad ejecutada Rust nativo / Rust-WASM / referencia
sustitución del Playground
autonomía completa de distribución
Garantía I
Garantía II
R1
R2
R3
R4
```

No existe R0-9.

Las obligaciones posteriores de WebAssembly y paridad deben abrirse mediante acto propio; no se infieren del cierre de la baseline.

---

## 16. Estado resultante

```text
R0-0 = FIJADO · CERRADO COMO CONTRATO V2
R0-1 = CERRADO · INTEGRADO
R0-2 = CERRADO · INTEGRADO
R0-3 = CERRADO · INTEGRADO
R0-4 = CERRADO · INTEGRADO
R0-5 = CERRADO · INTEGRADO
R0-6 = CERRADO · INTEGRADO
R0-7 = CERRADO · INTEGRADO
R0-8 = CERRADO · INTEGRADO

R0 = ABIERTO
  · subetapas numeradas R0-0…R0-8 completadas
  · obligaciones posteriores de WASM/paridad aún no abiertas

main =
acff3fb6555a99ab9536ea64c57af58e8d670f9a

R1–R4 = NO INICIADOS

Garantía I  = NO_PROBADO
Garantía II = NO_PROBADO
```

---

**DICTAMEN:** R0-8 queda cerrado e integrado como baseline nativa reproducible, acotada al SUT, perfil, protocolo e intervalos medidos. No se recomienda optimización previa al cierre; cualquier optimización futura deberá compararse contra esta baseline preservada y repetir las comprobaciones de equivalencia aplicables.
