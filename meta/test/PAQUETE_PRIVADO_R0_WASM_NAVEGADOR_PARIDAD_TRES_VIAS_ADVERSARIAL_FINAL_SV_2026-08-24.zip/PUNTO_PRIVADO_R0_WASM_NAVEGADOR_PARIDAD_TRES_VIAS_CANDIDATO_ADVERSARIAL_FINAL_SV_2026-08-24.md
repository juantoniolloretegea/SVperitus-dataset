# PUNTO PRIVADO — R0 / TARGET-WASM DE NAVEGADOR Y PARIDAD DE TRES VÍAS
## Candidato final para revisión adversarial independiente

**Fecha:** 24/08/2026  
**Naturaleza:** PRIVADA · NO PUBLICAR  
**Proyecto:** SV — Lenguaje de Computación  
**R0-0…R0-8:** CERRADOS · INTEGRADOS  
**R0:** ABIERTO  
**Acto WebAssembly/paridad:** MATERIALIZADO · REPRODUCIDO · CANDIDATO ADVERSARIAL · NO CERRADO · NO FUSIONADO  
**R1–R4:** NO INICIADOS  
**Garantía I / II:** NO_PROBADO  

---

## 1. Corte exacto

```text
repo =
juantoniolloretegea/SV-lenguaje-de-computacion

base main =
acff3fb6555a99ab9536ea64c57af58e8d670f9a

rama =
r0-wasm-paridad-tres-vias-2026-08-24

PR =
#22 · ABIERTO · FUSIONABLE · NO FUSIONADO

head congelado =
20a1f95cbf1bdbfb4f16cd39335bd71ca1d1c606

merge virtual probado =
f3f19f123ef5f119367572b7ce8f79a8e4cd7494
```

El merge virtual tiene como padres la base `acff3fb6…` y el `head` `20a1f95c…`.

---

## 2. Objeto contractual

El contrato posterior a R0-8 exige un destino WebAssembly del mismo núcleo y paridad ejecutada antes del cierre integral de R0.

El candidato ejerce:

```text
                           ┌→ Python / referencia diferencial
mismo texto .svp ─────────┼→ sv-native nativo / sv_core
                           └→ sv_wasm navegador / sv_core
```

y conserva una vía complementaria:

```text
mismo sv-native
→ wasm32-wasip1
→ host WASI
```

La prueba contractual es la ejecución real en navegador; WASI es evidencia complementaria.

No existe R0-9.

---

## 3. Navegador real

Destino:

```text
crate = sv_wasm
target = wasm32-unknown-unknown
navegador = Google Chrome 151.0.7922.137
```

El navegador carga el módulo `.wasm` mediante HTTP, escribe el texto `.svp` y el nombre de archivo en la memoria lineal del módulo y llama a:

```text
sv_compile_svp_json()
```

La función WebAssembly invoca:

```text
sv_core::compile_svp
→ bienformación soberana
→ IrProgram
→ sv_core::equivalence_json
```

No recibe IR, JSON Python ni objetos preconstituidos como entrada.

---

## 4. Una sola proyección diferencial

El PR mueve la proyección de equivalencia desde `sv_native` a:

```text
rust/sv_core/src/equivalence.rs
```

y la reexporta desde `sv_core`.

Después del cambio:

```text
sv_native → sv_core::equivalence_json
sv_wasm   → sv_core::equivalence_json
```

No hay una proyección independiente por adaptador.

La función sigue declarada expresamente como **proyección exclusiva de pruebas diferenciales de R0**, no como serializador canónico completo del Lenguaje.

Referencias de diff a inspeccionar:

```text
rust/sv_core/src/equivalence.rs
rust/sv_core/src/lib.rs
rust/sv_native/src/main.rs
```

---

## 5. ABI WebAssembly de navegador

La ABI nueva usa búferes internos del módulo:

```text
SOURCE_BUFFER
FILE_BUFFER
OUTPUT_BUFFER
```

Las funciones de host sólo obtienen posiciones de memoria para copiar bytes.

No existe transferencia manual de propiedad ni función `free` de la ABI.

En el cambio de `rust/sv_wasm/src/lib.rs` no se introduce ningún bloque `unsafe`.

La función de compilación:

```text
sv_compile_svp_json()
```

decodifica UTF-8 y llama directamente a `sv_core::compile_svp`.

---

## 6. JavaScript

El arnés:

```text
tests/r0_wasm_browser.js
```

contiene únicamente:

```text
TextEncoder/TextDecoder
copiado de bytes
instanciación WebAssembly
invocación de exports
desempaquetado ptr/len/error
comparación con oráculo de prueba
recuento y presentación del resultado
```

No contiene:

```text
lexer
parser
bienformación
IR
Tri semántico
Frame
resolve
gate
compose
query
reglas de admisión
serializador SV independiente
```

El manifiesto de navegador se genera en:

```text
tests/r0_wasm_browser_manifest.py
```

Para válidos, antes de registrar el `expected_stdout` nativo exige:

```text
Python = golden comprometido = nativo
```

El navegador recibe siempre el **texto fuente `.svp`** como entrada del módulo; el esperado sólo actúa como oráculo de prueba.

---

## 7. Corpus completo

Enumeración automática:

```text
tests/conformance/valid/*.svp
tests/conformance/invalid/*.svp
```

Corte:

```text
válidos = 11
inválidos = 61
total = 72
```

No existe selección manual cerrada de casos dentro del comparador.

---

## 8. Resultado navegador

El resultado DOM preservado indica:

```text
grammar = 0.2
ir = 0.3
serializer = 0.1.0

valid_ok = 11
invalid_ok = 61
failures = []
```

Para los 11 válidos:

```text
Python = golden = nativo   (canonización JSON)
WASM navegador = stdout nativo exacto
```

Para los 61 inválidos:

```text
Python rechaza
nativo rechaza
WASM navegador rechaza
```

No se acredita paridad exacta E*** ni igualdad textual de mensajes diagnósticos.

---

## 9. Resultado WASI complementario

Mismo `sv-native`, compilado a `wasm32-wasip1`.

Resultado:

```text
11/11 válidos equivalentes
61/61 inválidos rechazados
failures = []
diagnostic_parity = not-proven
```

Esta vía no se utiliza como sustituto del requisito navegador.

---

## 10. Reproducibilidad W1 — CERRADO

Dos reconstrucciones independientes del mismo `head` y mismo merge virtual preservan 23 piezas cada una.

Comparación interna:

```text
23 piezas totales
22 idénticas bit a bit
1 distinta = artifacts/r0-browser/http-server.log
```

La única diferencia es el registro operativo del servidor HTTP.

Son idénticos bit a bit entre ambos intentos:

```text
sv-native nativo
sv-native.wasm WASI
sv_wasm.wasm navegador
Cargo.lock
manifest.json de 72 casos
browser-parity-dom.html
three-way-parity-wasi.json
identidad Git relevante
toolchain registrado
```

Por tanto W1 queda cerrado.

---

## 11. Huellas críticas

### Nativo

```text
bytes =
877488

SHA-256 =
2db53e1bf7cd91cc1b228a423b8943f42acb2771173a3a5bb95cc0d149500d3f
```

### WebAssembly WASI complementario

```text
bytes =
389226

SHA-256 =
d008dcbe3db0dedc8edbc6a72579679b4082060596637f8f9d29ed1769cf51b6
```

### WebAssembly navegador contractual

```text
bytes =
337366

SHA-256 =
7b49228624f101dc8d863a2b4d631b7ed8eacb4ee4a29c2459d32f6b63aff5dc
```

### Manifiesto navegador

```text
SHA-256 =
fb50263bff1aba106a3205d16beea2761579a914cdc7705b8088b72d0c314819
```

### Resultado DOM navegador

```text
SHA-256 =
8bcc7991a3a588151242a306c5087087a14221a62433d18429c7e93392517880
```

### Resultado WASI

```text
SHA-256 =
5da0cc17b437e047840ab475101a0e4ed07fe4d3507b702a20e0ad6a816011fa
```

---

## 12. CI del mismo candidato

Sobre `head = 20a1f95c…`:

```text
Conformidad SVP #83 = SUCCESS
R0 Rust #63 = SUCCESS
R0-8 Baseline nativa #15 = SUCCESS
R0 WASM paridad de tres vías #11 = SUCCESS
```

El job de paridad WebAssembly fue repetido y ambos intentos terminaron con `SUCCESS`.

---

## 13. Relación con baseline R0-8

Baseline histórica cerrada:

```text
sv-native
876616 B
SHA-256 734027db…
```

Candidato actual:

```text
sv-native
877488 B
SHA-256 2db53e1b…
```

Diferencia de tamaño:

```text
+872 bytes
```

La diferencia deriva del refactor que centraliza la proyección diferencial en el núcleo.

La batería R0-8 se reejecuta sobre el candidato y permanece verde.

La baseline R0-8 **no se reescribe** y continúa siendo la referencia histórica anterior al cambio.

---

## 14. Límites que deben preservarse

```text
W2:
paridad exacta E*** / mensajes = NO PROBADA

W3:
Chrome real probado ≠ compatibilidad universal Firefox/Safari/WebKit

W4:
servidor HTTP + harness DOM = prueba contractual de navegador,
no prueba de CDN, distribución ni Playground final

W5:
equivalence_json = proyección diferencial compartida,
no serializador canónico completo

W6:
337366 B del módulo navegador = dato de este corte,
no obligación de optimizar antes de cerrar paridad

W7:
este candidato no autoriza por sí mismo TRL 5 cerrado,
certificación, Garantías I/II, autonomía ni R1
```

---

## 15. Playground

Estado:

```text
destino WebAssembly de navegador = MATERIALIZADO
paridad de corpus = MATERIALIZADA
Playground público migrado = NO
```

No debe afirmarse que el Playground ya funciona con Rust/WASM.

La cuestión para la revisión es si el contrato permite cerrar el acto WebAssembly/paridad y mantener la migración del Playground como acto posterior separado antes o después del cierre integral de R0, según su texto exacto.

---

## 16. Preguntas de falsación para la adversarial

1. ¿El `sv_wasm.wasm` realmente recibe `.svp` y atraviesa `sv_core::compile_svp`, o existe alguna preconstitución oculta?
2. ¿`equivalence_json` es verdaderamente única en el camino nativo/navegador después del diff?
3. ¿La centralización de `equivalence_json` introduce accidentalmente una nueva autoridad semántica en `sv_core`?
4. ¿El JavaScript puede alterar materialmente una decisión SV o sólo comparar/transportar?
5. ¿El manifiesto de navegador crea circularidad al usar stdout nativo como oráculo? Debe valorarse junto con la precondición `Python = golden = nativo`.
6. ¿La ABI con `RefCell<Vec<u8>>` y búferes internos elimina el `unsafe` nuevo sin introducir reentrada o aliasing material para el uso actual?
7. ¿La prueba de Chrome 151 satisface `TARGET-WASM = ejecución en navegador` sin exigir universalidad multi-browser?
8. ¿W1 queda legítimamente cerrado aunque el ZIP total difiera por `http-server.log`, dado que todos los artefactos probatorios son bit a bit idénticos?
9. ¿La reejecución verde de R0-8 basta para aceptar el +872 B sin reabrir la baseline histórica?
10. ¿La ausencia de paridad E*** sigue siendo un límite honesto y no un bloqueante bajo el alcance heredado?
11. ¿El módulo navegador de 337366 B presenta alguna señal objetiva que obligue a optimizar antes de cerrar la paridad?
12. ¿Debe migrarse el Playground antes de cerrar integralmente R0 según el contrato R0-0, o es una obligación posterior separada?
13. ¿Existe cualquier inflación hacia G-I/G-II, autonomía, TRL o R1? Debe poder responderse NO.

---

## 17. Estado candidato

```text
R0-0…R0-8 = CERRADOS · INTEGRADOS

WASM navegador contractual =
MATERIALIZADO · REPRODUCIDO

WASI =
COMPLEMENTARIO · REPRODUCIDO

paridad =
11/11 válidos
61/61 inválidos

W1 =
CERRADO

PR #22 =
ABIERTO · FUSIONABLE · NO FUSIONADO

acto WASM/paridad =
CANDIDATO DE CIERRE
NO CERRADO

R0 =
ABIERTO

R1–R4 =
NO INICIADOS

Garantía I / II =
NO_PROBADO

Playground migrado =
NO
```

---

**DICTAMEN PROVISIONAL:** no queda bloqueante técnico propio conocido para someter este `head` a adversarial independiente. El cierre y la fusión quedan deferidos. La revisión debe concentrarse especialmente en la legitimidad contractual del target navegador, la circularidad posible del oráculo, la ABI interna y la posición exacta del Playground respecto del cierre integral de R0.
