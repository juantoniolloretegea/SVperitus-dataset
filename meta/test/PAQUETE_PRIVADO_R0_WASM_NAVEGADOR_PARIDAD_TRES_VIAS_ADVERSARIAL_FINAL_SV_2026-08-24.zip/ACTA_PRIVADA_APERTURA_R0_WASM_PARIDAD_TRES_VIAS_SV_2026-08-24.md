# ACTA PRIVADA DE APERTURA — R0 / WEBASSEMBLY Y PARIDAD DE TRES VÍAS
## Obligación posterior a R0-8 y previa al cierre integral de R0

**Fecha:** 24/08/2026  
**Naturaleza:** PRIVADA · NO PUBLICAR  
**Proyecto:** SV — Lenguaje de Computación  
**R0-0…R0-8:** CERRADOS · INTEGRADOS  
**R0:** ABIERTO  
**R1–R4:** NO INICIADOS  
**Garantía I:** NO_PROBADO  
**Garantía II:** NO_PROBADO  

---

## 1. Autoridad

Por decisión humana expresa de 24/08/2026 queda abierto el acto propio posterior a R0-8 para:

```text
target WebAssembly del mismo núcleo Rust
+
paridad ejecutada de tres vías
```

No se crea R0-9.

---

## 2. Base exacta

```text
repo =
juantoniolloretegea/SV-lenguaje-de-computacion

main de apertura =
acff3fb6555a99ab9536ea64c57af58e8d670f9a

rama =
r0-wasm-paridad-tres-vias-2026-08-24
```

La rama nace exactamente sobre ese `main`.

---

## 3. Objeto probatorio

Debe ejercerse el mismo texto `.svp` por tres caminos:

```text
                 ┌→ Python, referencia diferencial
mismo .svp ──────┼→ Rust nativo
                 └→ Rust compilado a WebAssembly
```

Para casos válidos, el observable comprometido debe coincidir en las tres vías.

Para casos inválidos, las tres vías deben rechazar.

La paridad diagnóstica exacta E*** continúa fuera de alcance salvo prueba específica posterior.

---

## 4. Una sola semántica

La vía WebAssembly debe reutilizar el mismo `sv_core`.

Está prohibido:

```text
reescribir el analizador en JavaScript
reescribir bienformación en JavaScript
crear una segunda IR
crear una segunda semántica de Tri
alimentar al WASM con JSON ya producido por Python
usar fixtures precompilados como sustituto del .svp
```

El host WebAssembly puede proporcionar únicamente infraestructura de ejecución:

```text
memoria
argumentos
archivos
stdout/stderr
invocación de exports o ABI de sistema
```

sin tomar decisiones semánticas del Lenguaje.

---

## 5. Camino elegido de primera prueba

La primera materialización podrá compilar el propio `sv_native` a un objetivo WASI (`wasm32-wasip1`) y ejecutarlo mediante un host WASI.

Justificación:

```text
mismo main Rust
mismo compile_svp
mismo sv_core
misma proyección diferencial
distinto target de ejecución = WebAssembly
```

Esto evita introducir una segunda proyección o una segunda ABI semántica sólo para probar paridad.

La existencia de esta prueba no convierte al adaptador WASI en el adaptador definitivo del Playground.

---

## 6. Adaptador de navegador

El crate `sv_wasm` existente permanece como adaptador WebAssembly de navegador y debe continuar compilando contra el mismo `sv_core`.

La paridad WASI acredita ejecución WebAssembly del camino soberano; la sustitución posterior del Playground exigirá además una interfaz de navegador delgada que no replique semántica.

---

## 7. Corpus

La prueba debe recorrer automáticamente:

```text
tests/conformance/valid/*.svp
tests/conformance/invalid/*.svp
```

sin listas manuales cerradas que puedan ocultar crecimiento posterior del corpus.

---

## 8. Identidad

Antes de considerar la paridad cerrable deben registrarse:

```text
main/base
head
merge virtual de CI
Rust exacto
target WASM exacto
versión del host WASI
SHA-256 del binario nativo
SHA-256 del módulo .wasm
corpus exacto
resultados por caso
```

---

## 9. Criterio de válidos

Para cada válido:

```text
Python = golden comprometido
Rust nativo = Python
Rust-WASM = Rust nativo
```

La comparación se realiza sobre JSON canónico de prueba.

Ese JSON continúa siendo una proyección diferencial, no una declaración de serializador canónico completo.

---

## 10. Criterio de inválidos

Para cada inválido:

```text
Python rechaza
Rust nativo rechaza
Rust-WASM rechaza
```

No se exige igualdad exacta de códigos diagnósticos ni mensajes de error.

---

## 11. No efectos

Esta apertura no:

```text
cierra R0
abre R1
abre R2
abre R3
abre R4
prueba Garantía I
prueba Garantía II
sustituye el Playground
declara autonomía completa de distribución
convierte JavaScript en semántica SV
```

---

## 12. Criterio de cierre

El acto será cerrable sólo cuando:

1. exista ejecución real WebAssembly del mismo núcleo;
2. el corpus válido completo muestre paridad de las tres vías;
3. el corpus inválido completo muestre rechazo por las tres vías;
4. el adaptador WebAssembly no introduzca semántica paralela;
5. `sv_wasm` continúe compilando contra el mismo núcleo;
6. la CI del candidato exacto sea verde;
7. la identidad de artefactos quede preservada;
8. una revisión adversarial no encuentre bloqueante reproducible.

Sólo entonces podrá plantearse por acto humano separado el cierre integral de R0.

---

**DICTAMEN DE APERTURA:** queda abierto el frente WebAssembly + paridad de tres vías sobre `main = acff3fb6555a99ab9536ea64c57af58e8d670f9a`, sin R0-9 y sin apertura de R1.
