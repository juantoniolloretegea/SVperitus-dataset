# Dominio clínico de inmunología · CSV de parámetros

**Nota de método que acompaña a `DOMINIO-INMUNOLOGIA-PARAMETROS.csv`**
Fecha: 31 de agosto de 2026 · 196 filas
Unidad redactora: Claude · Decisión editorial: el director

---

## 1 · De dónde salen las familias

Las familias **no las he inventado ni las he elegido**. Son las áreas curriculares que la propia especialidad declara en la sección «Presentations and conditions» de sus dos currículos aprobados por el GMC:

- **ACLI 2021** — *Curriculum for Immunology (Allergy, Clinical and Laboratory Immunology) Training*, implantación agosto de 2021, §3.3, §3.4 y §3.5.
- **ACI 2021** — *Curriculum for Allergy (Allergy and Clinical Immunology) Training*, implantación agosto de 2021, §3.3, §3.4 y §3.5.

Ambos leídos íntegros el 31 de agosto de 2026 en `gmc-uk.org` y `thefederation.uk`.

| Cód. | Familia | Origen |
|---|---|---|
| F1 | Urgencias alérgicas e inmunológicas | Área curricular declarada |
| F2 | Enfermedades alérgicas y sus mímicos | Área curricular declarada |
| F3 | Inmunodeficiencia | Área curricular declarada |
| F4 | Terapéutica alergológica e inmunológica | Área curricular declarada |
| F5 | Enlace de alergia | Área curricular declarada |
| F6 | Enlace de inmunología clínica y de laboratorio | Área curricular declarada |
| F7 | Inmunología de laboratorio | Área curricular declarada, **sólo en la vía ACLI** |
| P | Procedimientos prácticos | §3.5, sección propia, **no** es un área curricular |
| C | Capacidades en la práctica | §3.2 y §3.3, eje de capacidad, **no** de contenido clínico |

**La elección de jurisdicción tampoco es mía.** Watson dejó registrada una reserva: una etapa temprana del trabajo mencionaba EAACI/EACCI/GMC/ABAI, mientras que el preprint canónico usa RACP, Royal College of Physicians and Surgeons of Canada, GMC y ACGME, sin justificación explícita de la sustitución. He tomado el eje **GMC** de esa lista canónica porque es el único de los cuatro cuyo currículo he podido leer íntegro y citar por sección en este turno. **RACP, RCPSC y ACGME quedan sin leer: U con causa**, y aparecen en el §6 como frente abierto.

---

## 2 · Qué es una fila

Cada fila es un elemento que el currículo enumera, con estas columnas:

- `parametro` — enunciado en español.
- `denominacion_fuente_en` — la denominación tal como figura en la fuente, para poder volver a ella.
- `argumento` — por qué pertenece al dominio y qué decisión toca.
- `consecuencia_si_se_ignora` — la consecuencia de omitirlo.
- `estatuto_consecuencia` — **y esta es la columna que impide el autoengaño.**

### La regla que gobierna la columna `estatuto_consecuencia`

Usted la fijó y no la he tocado: **el currículo prueba exigencia formativa; no demuestra por sí solo el daño clínico derivado de ignorarla.** Por tanto:

| Valor | Significado | Filas |
|---|---|---|
| `ANCLADA_CURRICULO` | La consecuencia, o la criticidad que la sostiene, está **nombrada en el propio currículo** | 63 |
| `PENDIENTE_FUENTE` | La consecuencia es **hipótesis por evidenciar** con guía, norma, serie o caso documentado | 131 |
| `U` | No he podido formular consecuencia a partir de la fuente | 2 |

**Dos tercios del CSV están en `PENDIENTE_FUENTE`.** Eso no es un defecto del trabajo: es su estado real. Cerrar esas 131 filas exige fuente clínica, no curricular, y es tarea nombrada, no U de comodidad.

La columna `aporta_consecuencia` marca aparte las filas que **no cualifican** como parámetro con consecuencia identificable: `NO` en 2 filas (prurito, tos: síntomas listados sin desarrollo) y `PARCIAL` en 6. Se conservan por integridad del dominio, marcadas.

---

## 3 · La escala de prioridad 1–20

Ordena por **proximidad de la omisión al daño y reversibilidad de éste**, no por familia. Un fallo de laboratorio no va al final por ser de laboratorio: va donde corresponde por su alcance.

| Banda | Criterio |
|---|---|
| 1–3 | Omisión que puede matar o producir daño irreversible en minutos u horas |
| 4–6 | Omisión que produce daño irreversible en días o semanas |
| 7–9 | Omisión que suprime una acción protectora sostenida, o que consolida un etiquetado erróneo |
| 10–12 | Omisión que produce sobretratamiento, restricción injustificada o pérdida de continuidad |
| 13–15 | Omisión de gobierno, transición o comunicación |
| 16–20 | Reservado |

**Las bandas 16, 18, 19 y 20 han quedado vacías.** No las he rellenado para completar la escala. Que estén vacías es información: en este dominio, tal como lo declara la especialidad, no hay elementos de consecuencia tan remota.

### `estatuto_prioridad`: qué sostiene cada número

| Valor | Significado | Filas |
|---|---|---|
| `ANCLADA` | La prioridad se apoya en algo que **la especialidad publica**: pertenencia al área de urgencias, año de delegación no supervisada del procedimiento, o consecuencia nombrada en el currículo | 69 |
| `PROPUESTA` | La prioridad es aplicación mía de la rúbrica; **contestable, y su resolución es del director** | 127 |

El indicador de riesgo más limpio que publica la especialidad es el **año de competencia no supervisada** de la tabla de procedimientos (§3.5): punción cutánea en ST3, prueba intradérmica en ST4, provocación con fármaco y con alimento en ST6, **desensibilización a fármacos en ST7**, que es el último. Esa gradación es un juicio de riesgo emitido por la propia especialidad, no por mí, y la he usado como ancla.

---

## 4 · Fronteras y límites que declara la especialidad

La columna `frontera_o_limite_declarado` recoge, fila a fila, dónde la propia especialidad marca su límite. Las de mayor consecuencia:

1. **Remisión externa nominal.** Para la inmunodeficiencia primaria el currículo no enumera: remite a las definiciones más recientes de **ESID o IUIS** y las declara expresamente lista **no exhaustiva**. La frontera del subdominio está fuera del currículo, en un documento que cambia.
2. **Resultados que no clausuran.** Cuatro casos declarados: angioedema por bradicinina con C1 inhibidor **normal**; hipersensibilidad **no** mediada por IgE (una IgE negativa no excluye); condiciones inducidas por **cofactor** (una provocación sin cofactor no descarta); y causas **no alérgicas** de IgE total elevada (un positivo no confirma). Cuatro puntos donde el dato de laboratorio, por sí solo, no cierra la cuestión.
3. **El falso positivo tiene familia propia.** «Condiciones que imitan enfermedad alérgica» y «medicina no basada en la evidencia y complementaria en alergia» son categorías curriculares. El dominio declara que diagnosticar de más también es daño.
4. **El error preanalítico es silencioso.** Crioproteínas y crioglobulinas dependen del manejo de la muestra, no del ensayo; ningún control de calidad del analizador lo detecta.
5. **El destinatario del daño no siempre es el paciente.** El bloque de práctica segura de laboratorio (manejo de muestras, COSHH, RIDDOR, radiactividad) protege al trabajador. Es el único del dominio con esa frontera.
6. **Una entrada agrupa urgencias muy distintas.** «Glomerulonefritis membranosa, postinfecciosa, anti-MBG y membranoproliferativa» figura como una sola entrada, y sólo una de las cuatro exige tratamiento en horas.
7. **Divergencia entre las dos vías del mismo currículo.** La inmunoterapia con aeroalérgenos y con veneno alcanza competencia no supervisada un año antes en ACI (ST4) que en ACLI (ST5); la desensibilización a fármacos, en ST6 frente a ST7. Registrado como dato, no corregido.
8. **Duplicidades declaradas.** Anafilaxia, bronquiectasias no explicadas, cicatrización deficiente, fiebre recurrente y las inmunodeficiencias figuran en más de un área. No son errores de transcripción: son cruces reales del propio currículo y así están marcados en `observaciones`.
9. **Discrepancia ortográfica de la fuente.** ACLI escribe «angiodema» donde ACI escribe «angioedema». Registrado; no se corrige la fuente.
10. **Ambigüedad no resuelta de la fuente.** «Irritable Bowel Disease» no permite distinguir con certeza entre enfermedad inflamatoria intestinal e intestino irritable. Registrado como ambigüedad, no interpretado.

---

## 5 · Lo que este CSV no hace

Por instrucción expresa suya, y lo respeto:

- **No ordena el dominio en células ni propone tipado SV.** No hay ninguna columna que sugiera longitud de vector, estrato, puente ni composición.
- **No decide qué entra en un módulo.** La columna `prioridad` es un filtro, no un corte.
- **No fija población, fecha de corte ni operaciones.** Eso es la puerta D1 del documento de gobierno y no le corresponde a este fichero.
- **No afirma cobertura de la especialidad.** El propio currículo declara que ofrece orientación general y no detalle exhaustivo, «que inevitablemente quedaría desactualizado». Este CSV cubre lo que el currículo enumera, y eso no es lo mismo que la inmunología.

---

## 6 · Frente abierto, nombrado

1. **RACP, RCPSC y ACGME sin leer.** Los tres restantes del conjunto canónico. Hasta leerlos, el eje curricular de este CSV es de jurisdicción única.
2. **131 filas en `PENDIENTE_FUENTE`.** Cada una necesita fuente clínica que evidencie la consecuencia. Es el trabajo que convierte un catálogo formativo en un dominio con consecuencias medibles.
3. **La lista de IUIS/ESID vigente no consultada.** El currículo remite a ella para toda la inmunodeficiencia primaria; sin leerla, la familia F3 tiene su frontera declarada pero no desplegada.
4. **127 prioridades en `PROPUESTA`.** Contestables una a una.
5. **Correspondencia con los datos reales sin comprobar.** Ninguna fila está aún cotejada contra un diccionario de variables de repositorio. Ése es el cruce con la puerta D0 y con SDY3324, y decide qué parte de este catálogo es observable y qué parte no.

---

## 7 · Fuentes

- GMC/JRCPTB, *Curriculum for Immunology (Allergy, Clinical and Laboratory Immunology) Training*, agosto de 2021 — `https://www.thefederation.uk/sites/default/files/Immunology%20(Allergy%20Clinical%20and%20Laboratory%20%20Immunology)%202021%20curriculum%20FINAL.pdf`
- GMC/JRCPTB, *Curriculum for Allergy (Allergy and Clinical Immunology) Training*, agosto de 2021 — `https://www.gmc-uk.org/cdn/documents/allergy--allergy-and-clinical-immunology--2021-curriculum-final_pdf-86838515.pdf`
- JRCPTB, página de especialidad de Inmunología — `https://www.thefederation.uk/training/specialties/immunology`

Ambos currículos consultados íntegros el 31 de agosto de 2026.
