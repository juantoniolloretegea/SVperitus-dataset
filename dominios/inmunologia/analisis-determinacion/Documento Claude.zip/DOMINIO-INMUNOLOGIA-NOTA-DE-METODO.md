# Dominio clínico de inmunología · acotación y contenido

**Nota de método · versión 2 · 31 de agosto de 2026**
Acompaña a `DOMINIO-INMUNOLOGIA-COTA-ES.csv` — 167 filas, 17 columnas
SHA-256 del CSV: `b0ab78bfe2327fb1242456befff46c3720f6582a23f7870193f49ba4fab6cbe6`

**Sustituye íntegramente a la versión 1 y al fichero `DOMINIO-INMUNOLOGIA-PARAMETROS.csv`, ambos retirados.**

---

## 1 · Qué estaba mal en la versión 1

Transcribí las listas ilustrativas de un currículo docente británico y las entregué como catálogo del dominio. Ese currículo declara en la misma sección que ofrece orientación general y no detalle exhaustivo, «que inevitablemente quedaría desactualizado». Construí un censo sobre una fuente que se declara no censal.

Y confundí nomenclatura con parámetros: 196 rótulos de enfermedad no son 196 parámetros.

---

## 2 · La acotación

El dominio no es infinito ni arbitrario: **queda acotado por lo que se exige como conocimiento médico a quien se forma en la especialidad**. Sobre esa cota se despliega después el contenido vigente. Dos operaciones distintas y en este orden.

### 2.1 · La cota: qué exige la norma

**España — Orden SCO/3255/2006, de 2 de octubre** (BOE núm. 252, de 21 de octubre de 2006, páginas 36894 a 36903; referencia BOE-A-2006-18430; ELI `https://www.boe.es/eli/es/o/2006/10/02/sco3255`). Programa formativo de la especialidad de Inmunología, elaborado por la Comisión Nacional de la Especialidad, verificado por el Consejo Nacional de Especialidades Médicas al amparo del artículo 21 de la Ley 44/2003. Texto íntegro leído el 31 de agosto de 2026.

No es una guía docente: es una orden ministerial. Ésa es la diferencia con la versión 1.

El CSV enumera lo que esa norma declara en sus apartados 5.1 (conocimientos, diecisiete bloques), 5.2 (metodología de laboratorio, seis bloques), 5.3 (inmunología clínica, tres bloques), 5.5 (bioética) y 6.5 (tabla de actividades por nivel de responsabilidad).

**Reino Unido — cotejo, no cota.** Cada fila lleva su correspondencia con los currículos ACLI 2021 y ACI 2021 aprobados por el GMC, leídos también el 31 de agosto de 2026.

### 2.2 · El contenido: qué hay hoy dentro de esa cota

La norma española es de 2006. Sus renglones siguen obligando; su contenido lo fijan hoy los catálogos de custodio, con cardinalidad verificada en este turno:

| Custodio | Catálogo | Cardinalidad verificada |
|---|---|---|
| IUIS, comité de errores innatos de la inmunidad | Clasificación fenotípica, actualización 2024 | **559 entidades**, sobre 508 genes y 17 fenocopias, en diez grupos |
| OMS e IUIS, subcomité de nomenclatura de alérgenos | Allergen Nomenclature Database | **1.148 alérgenos**, de ellos 410 alimentarios |
| ImmPort (NIAID/DAIT) | `lk_analyte` | **921 analitos** |
| ImmPort | `lk_disease` | **371 enfermedades** |
| ImmPort | `lk_lab_test_name` | **333 pruebas** |
| ImmPort | `lk_exposure_material` | **103 materiales de exposición** |
| ImmPort | `lk_cell_population` | **92 poblaciones celulares** |

Los recuentos de ImmPort están contados por mí sobre la página servida el 31 de agosto de 2026, no citados de memoria.

**El desfase es el hallazgo, no el defecto.** La norma dedica un renglón a «inmunodeficiencias primarias»; el catálogo de custodio vigente describe 559 entidades. Dedica un renglón a «cuantificación de IgE total e IgE específica»; el catálogo de alérgenos tiene 1.148 entradas. Nombra seis genes en el apartado 5.2.5; el catálogo de 2024 clasifica 508. La obligación profesional está redactada en 2006 y su contenido se ha multiplicado desde entonces. Ahí es donde la omisión tiene consecuencia: no en la lista, sino en la distancia entre lo exigido y lo vigente.

---

## 3 · Qué dice el fichero

167 filas: 73 de conocimiento, 67 de técnica de laboratorio, 16 de actividad clínica, 5 de gestión, 5 de bioética, 1 de actividad de laboratorio declarada por volumen.

### 3.1 · Fronteras que declara la propia norma

1. **La competencia está partida por titulación de origen.** A la especialidad acceden licenciados en Medicina, Biología, Bioquímica y Farmacia. El apartado 3.2.1 fija lo común a todos —técnica, interpretación, protocolos, investigación— y el 3.2.2 reserva a los licenciados en Medicina el diagnóstico y el tratamiento. En el CSV: **16 filas reservadas a Medicina, 151 comunes.** Ninguna otra cota examinada parte así el dominio.

2. **En España, Alergología es otra especialidad.** Orden SCO/3081/2006 (BOE-A-2006-17620), cuatro años, acceso sólo desde Medicina. En el Reino Unido, alergia e inmunología son la misma especialidad con dos vías. **La frontera del dominio cambia de forma según la jurisdicción**: por eso la cota española dedica a inmunoalergia un bloque de cuatro renglones donde la británica dedica un área curricular entera.

3. **Volúmenes mínimos declarados.** Mínimo anual de 2.000 informes inmunológicos de laboratorio; 100 informes clínicos inmunológicos para los MIR que roten por unidades clínicas especializadas. Son las únicas cifras de actividad que la norma fija.

4. **Delegación por nivel de responsabilidad.** El apartado 6.5 asigna a 38 actividades un nivel 1, 2 o 3 por año de residencia. Nivel 1 desde R1 en conocimiento teórico y en bioética: la norma no admite tutela en esas materias. Y una sola actividad no alcanza el nivel 1 en R4, la **consulta especializada**, que se queda en nivel 2. Es la delegación más tardía de todo el programa español y es un juicio de riesgo emitido por la propia especialidad.

5. **Materias que la cota española nombra y la británica no.** VIH y sida como epígrafe propio con cuatro técnicas asociadas; inmunotoxicología completa; autoinmunidad ocular; autoinmunidad reproductora, con infertilidad y aborto de causa inmunológica; indicaciones y contraindicaciones de vacunas e inmunización del paciente inmunodeficiente; protección radiológica. **81 de las 167 filas no tienen equivalente declarado en el currículo británico.** Casi la mitad: dos cotas presentadas como equivalentes divergen en la mitad de su contenido.

6. **Renglones que agrupan urgencias desiguales.** El apartado 5.2.3 mete en una sola línea los anticuerpos específicos de tejido, y ahí dentro va el anti-membrana basal glomerular, cuya omisión se mide en horas, junto a otros seis sin urgencia comparable.

7. **Exigencia condicionada.** El apartado 5.2.6 declara que el residente deberá conocer alguna de las tecnologías citadas «dependiendo de las posibilidades de cada centro». Es el único punto donde la norma condiciona la exigencia al centro, y por tanto el único donde la cota no es uniforme en el territorio.

### 3.2 · Las dos columnas que impiden el autoengaño

`estatuto_consecuencia`, con la regla que usted fijó —el currículo prueba exigencia formativa, no daño clínico—: **35 filas ancladas** en algo que la norma o el cotejo nombran, **132 pendientes de fuente clínica**. Ninguna U.

`estatuto_prioridad`: **36 ancladas** en el nivel de responsabilidad del apartado 6.5 o en la pertenencia a urgencia declarada; **131 propuestas** mías y contestables una a una.

### 3.3 · La prioridad

Misma escala 1–20, por proximidad de la omisión al daño y reversibilidad. Doce filas en prioridad 1: enfermedad del injerto contra el huésped por transfusión, prueba cruzada para trasplante, anticuerpos citotóxicos anti-HLA, adenosina desaminasa y purín-nucleótido fosforilasa, mutaciones génicas en inmunodeficiencia combinada, subtipos linfocitarios, anticuerpos anti-membrana basal glomerular, confirmación de infección por VIH, infección en el huésped inmunosuprimido, urticaria y anafilaxia, contraindicaciones vacunales, e inmunización del paciente inmunodeficiente.

Las bandas 15 a 18 y la 20 han quedado vacías. No las relleno.

---

## 4 · Lo que este fichero sigue sin hacer

- No ordena en células ni propone tipado. Ninguna columna sugiere longitud, estrato, puente ni composición.
- No fija población, corte ni operaciones.
- **No es la inmunología: es la obligación profesional declarada en una jurisdicción**, con su contenido vigente señalado por custodio. La distinción entre dominio profesional, dominio clínico operativo y centinela del lenguaje queda intacta.

---

## 5 · Frente abierto, nombrado

1. **Vigencia de la norma sin verificar.** He leído el texto original de 2006. No he comprobado si existe disposición posterior que lo modifique o sustituya. **U con causa**, y es la primera comprobación que corresponde hacer.
2. **Programa de Alergología (Orden SCO/3081/2006) sin enumerar.** En España es dominio contiguo y separado; sin él, la cota española está incompleta por su lado alergológico.
3. **ACGME, RCPSC y RACP sin leer.** Los tres restantes del conjunto canónico. Hasta leerlos, el cotejo es de dos jurisdicciones.
4. **132 filas pendientes de fuente clínica.** Es el trabajo que convierte obligación formativa en consecuencia medible.
5. **Los catálogos de custodio están contados, no descargados.** Conozco su cardinalidad; no tengo sus entradas. Descargarlos es la operación que despliega el contenido dentro de la cota.

---

## 6 · Fuentes

- Orden SCO/3255/2006, de 2 de octubre, programa formativo de la especialidad de Inmunología — `https://www.boe.es/buscar/doc.php?id=BOE-A-2006-18430`
- Orden SCO/3081/2006, de 20 de septiembre, programa formativo de la especialidad de Alergología — `https://www.boe.es/buscar/doc.php?id=BOE-A-2006-17620`
- GMC/JRCPTB, *Curriculum for Immunology (Allergy, Clinical and Laboratory Immunology) Training*, 2021 — `https://www.thefederation.uk/sites/default/files/Immunology%20(Allergy%20Clinical%20and%20Laboratory%20%20Immunology)%202021%20curriculum%20FINAL.pdf`
- GMC/JRCPTB, *Curriculum for Allergy (Allergy and Clinical Immunology) Training*, 2021 — `https://www.gmc-uk.org/cdn/documents/allergy--allergy-and-clinical-immunology--2021-curriculum-final_pdf-86838515.pdf`
- IUIS, *Human inborn errors of immunity: 2024 update on the classification* — `https://rupress.org/jhi/article/1/1/e20250003/277390/Human-inborn-errors-of-immunity-2024-update-on-the`
- IUIS, *The 2024 update of IUIS phenotypic classification of human inborn errors of immunity* — `https://rupress.org/jhi/article/1/1/e20250002/277374/The-2024-update-of-IUIS-phenotypic-classification`
- Cardinalidad de la base de nomenclatura de alérgenos OMS/IUIS, tomada de un artículo de *Database* de 2026 — `https://academic.oup.com/database/article-pdf/doi/10.1093/database/baag028/68406276/baag028.pdf`
- Vocabularios controlados de ImmPort — `https://docs.immport.org/datasubmission/templatedocumentation/lktables/`

Todas consultadas el 31 de agosto de 2026.
