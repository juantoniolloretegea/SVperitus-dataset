# Anexo de continuidad de OP-CYB-001

El catálogo principal es el Excel v0.10. La proyección JSON es complementaria y se generó después de cerrarlo, mediante dos lecturas sin modificarlo. La identidad consta en VINCULACION_LIBRO_Y_PROYECCION_v0.10.json.

Los 32 testigos son sintéticos. Sus expectativas están fijadas en testigos.json; el auxiliar externo contrastar.py no implementa el Lenguaje SV. Comprueba relaciones documentales y detecta once versiones erróneas del observador. No valida firmas, identidad, facultades institucionales, registros reales ni controles de red. Sus resultados nominales pertenecen al ensayo, no al alfabeto SV.

Para reproducir la campaña, ejecutar `python3 contrastar.py resultado_reproducido.json` en este directorio y comparar sus bytes con resultados.json. Sólo requiere la biblioteca estándar. La repetición exacta acredita este ensayo documental, no ejecución productiva de Q0. Las huellas textuales de algunos testigos son ficticias.

Para verificar la proyección, importar la función projection de proyeccion.py, pasarle los bytes del Excel y comparar el resultado con PROYECCION_COMPLEMENTARIA_CATALOGO_v0.10.json. No se guarda de nuevo el Excel. No se incluyen documentos completos de terceros.

RS09–RS12 precisan necesidades para la decisión humana sobre el siguiente contraste. No envían una orden al Lenguaje ni abren otro universo. La relación entre información, autoridad, deber y responsabilidad se conserva en los documentos sustantivos.
