"""Auxiliar documental externo. No ejecuta SV, autenticación, custodia ni infraestructura."""
from pathlib import Path
import json, hashlib, sys
def observar(c,m=None):
 d=c['datos'];k=c['clase']
 if k=='partida':
  if d['origen']=='genesis_demostrada' and d['historia_previa']=='desconocida' and m!='genesis':return 'AFIRMACION_NO_SOSTENIDA'
  if not d['cobertura_acreditada'] or set(d['ambito'])!=set(d['observados']):return 'NO_CONCLUYENTE'
  if not d['instante_observacion']<=d['instante_acto']<=d['limite_vigencia'] and m!='tiempo_partida':return 'NO_CONCLUYENTE'
  return 'PARTIDA_ACOTADA'
 if k=='linaje':
  for i,h in d['referencias'].items():
   if i not in d['nodos']:return 'NO_CONCLUYENTE'
   if d['nodos'][i]!=h:return 'EVIDENCIA_NO_ADMITIDA'
  grafo={i:[] for i in d['nodos']}
  for a,b,t,respaldo in d['relaciones']:
   if a not in grafo or b not in grafo:return 'NO_CONCLUYENTE'
   if t not in ['derivacion','referencia','precedencia_estricta','causa']:return 'EVIDENCIA_NO_ADMITIDA'
   if t=='causa' and not respaldo and m!='causalidad':return 'NO_CONCLUYENTE'
   if t in ['derivacion','precedencia_estricta','causa'] or m=='todo_ciclo':grafo[a].append(b)
  activo=set();visto=set()
  def ciclo(n):
   if n in activo:return True
   if n in visto:return False
   activo.add(n)
   if any(ciclo(q) for q in grafo[n]):return True
   activo.remove(n);visto.add(n);return False
  if any(ciclo(n) for n in grafo):return 'EVIDENCIA_NO_ADMITIDA'
  return 'RELACIONES_CONSERVADAS'
 if k=='asignacion':
  if d['exonera_anterior'] and m!='exoneracion':return 'AFIRMACION_NO_SOSTENIDA'
  if (d['clase_documento']!='designacion' and m!='heredar_responsabilidad') or not d['facultad_acreditada']:return 'ASIGNACION_NO_ACREDITADA'
  if d['efecto']>d['instante']:return 'NO_CONCLUYENTE'
  if d['aceptacion_exigida'] or m=='aceptacion_universal':
   a=d['aceptacion']
   if not a or a['titular']!=d['titular'] or a['obligacion']!=d['obligacion'] or a['instante']>d['instante']:return 'NO_CONCLUYENTE'
  return 'ASIGNACION_ACREDITADA_EN_PERFIL'
 if k=='conciliacion':
  if not d['cobertura_acreditada']:return 'NO_CONCLUYENTE'
  estados=set(d['inicio']);prev={}
  for e in d['movimientos']:
   if e['id'] in prev:
    if prev[e['id']]!=e:return 'EVIDENCIA_NO_ADMITIDA'
    continue
   prev[e['id']]=e
   if e['clase']!=d['clase']:return 'EVIDENCIA_NO_ADMITIDA'
   if e['accion']=='efecto_incierto':return 'NO_CONCLUYENTE'
   if e['accion']=='alta':
    if e['objeto'] in estados:return 'EVIDENCIA_NO_ADMITIDA'
    estados.add(e['objeto'])
   elif e['accion']=='baja':
    if e['objeto'] not in estados:return 'EVIDENCIA_NO_ADMITIDA'
    estados.remove(e['objeto'])
   else:return 'EVIDENCIA_NO_ADMITIDA'
  coincide=len(estados)==len(d['fin']) if m=='solo_cantidad' else estados==set(d['fin'])
  return 'CONCILIACION_COINCIDENTE' if coincide else 'CONCILIACION_DISCORDANTE'
 if k=='perimetro':
  if not d['trayectos']:return 'NO_CONCLUYENTE'
  cubiertos={p['trayecto'] for p in d['pruebas'] if p['generacion']==d['generacion'] and p['valida_hasta']>=d['instante'] and p['resultado']=='favorable'}
  cumple=bool(cubiertos) if m=='un_trayecto' else set(d['trayectos'])<=cubiertos
  return 'COBERTURA_ACREDITADA_EN_PERFIL' if cumple else 'COBERTURA_INSUFICIENTE'
 if k=='vigencia':
  for e in d['cambios']:
   if e['objeto'] not in d['dependencias'] and m!='todo_cambio':continue
   if e['efecto'] is None:return 'NO_CONCLUYENTE'
   if e['efecto']<=d['instante_acto'] or m=='retroactividad':return 'REQUIERE_REEVALUACION'
  return 'SIN_CAMBIO_PERTINENTE_DECLARADO'
 raise ValueError('Clase documental no constituida')
def main():
 r=Path(__file__).resolve().parent;casos=json.loads((r/'testigos.json').read_text())
 resultados=[dict(id=c['id'],esperado=c['esperado'],observado=observar(c)) for c in casos]
 assert all(x['esperado']==x['observado'] for x in resultados),resultados
 mutaciones=[]
 for m in ['genesis','tiempo_partida','causalidad','todo_ciclo','exoneracion','heredar_responsabilidad','aceptacion_universal','solo_cantidad','un_trayecto','todo_cambio','retroactividad']:
  ids=[c['id'] for c in casos if observar(c,m)!=c['esperado']]
  assert ids,m
  mutaciones.append(dict(mutacion=m,refutadores=ids))
 salida=dict(alcance='Contrato documental sintético; no ejecución del Lenguaje SV ni verificación de hechos reales',resultados=resultados,mutaciones=mutaciones)
 b=(json.dumps(salida,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
 p=Path(sys.argv[1]) if len(sys.argv)>1 else r/'resultados.json';p.write_bytes(b)
 print(json.dumps(dict(casos=len(casos),discordancias=0,mutaciones_detectadas=len(mutaciones),sha256=hashlib.sha256(b).hexdigest())))
if __name__=='__main__':main()
