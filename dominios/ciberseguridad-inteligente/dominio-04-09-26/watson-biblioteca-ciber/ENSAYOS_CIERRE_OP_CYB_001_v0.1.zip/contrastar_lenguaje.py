from pathlib import Path
import json,hashlib,subprocess,sys
R=Path(__file__).resolve().parent
exe=Path(sys.argv[1]);expected_sha='cb0db4112cea29ed01972f88a549b0add8bb43a261034f0e8f37cb04974b8e7a'
assert hashlib.sha256(exe.read_bytes()).hexdigest()==expected_sha
# Corrección fundada del oráculo inicial: sin CellSpec no existe enlace
# entre Codomain y OutputSemantics que permita exigir totalidad relativa.
oracles=[dict(file='contrato.es.svp',exit=0,reason='Transporte de declaraciones nominales sin operaciones'),dict(file='semantica_incompleta.es.svp',exit=0,reason='No hay asociación constituida con codominio; el ataque no alcanza totalidad'),dict(file='semantica_duplicada.es.svp',exit=1,reason='E115: la unicidad de mapping sí se alcanza sin arquitectura')]
(R/'ORACULOS_SVP_CORREGIDOS.json').write_text(json.dumps(oracles,ensure_ascii=False,indent=2)+'\n')
results=[]
for x in oracles:
 p=R/'contraste_svp'/x['file'];cmd=[str(exe),'--profile','es',str(p)]
 a=subprocess.run(cmd,capture_output=True);b=subprocess.run(cmd,capture_output=True)
 assert a.returncode==x['exit'];assert (a.returncode,a.stdout,a.stderr)==(b.returncode,b.stdout,b.stderr)
 (R/'contraste_svp'/(x['file']+'.stdout')).write_bytes(a.stdout);(R/'contraste_svp'/(x['file']+'.stderr')).write_bytes(a.stderr)
 if x['exit']==0:
  data=json.loads(a.stdout);assert data['operations']==[]
  capture=next(o for o in data['objects'] if o['type']=='CaptureSpec');assert capture['fields']['mapping']=='CapturadorNoEjecutado'
 else:assert b'E115' in a.stderr
 results.append(x|dict(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),stdout_sha256=hashlib.sha256(a.stdout).hexdigest(),stderr_sha256=hashlib.sha256(a.stderr).hexdigest(),repeticion_bytes_identicos=True,observacion='No ejecuta capturador ni consejo CYB'))
report=dict(corte_tecnico='ab61d9bb7a2002d3a4a389e292c2a9b0a850d264',binary_sha256=expected_sha,casos=results,dictamen='SUFICIENCIA_LIMITADA_EN_TRANSPORTE_NOMINAL_Y_UNICIDAD; TOTALIDAD_NO_ENSAYADA; EJECUCION_Q0_NO_ACREDITADA',rectificacion='Oráculo inicial de totalidad incorrecto por falta de asociación con codominio. Se conserva original; no se cuenta como defecto del Lenguaje ni como prueba favorable de totalidad.',limite='No se ha recompilado Rust ni ejecutado sonda GH/LIG en este turno. No hay segunda realización semántica.')
(R/'RESULTADOS_LENGUAJE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
