"""Observador documental de testigos sintéticos; no es compilador ni agente SV."""
from pathlib import Path
from decimal import Decimal,InvalidOperation
import json,hashlib,re,subprocess,platform,sys,copy
R=Path(__file__).resolve().parent
def h(b):return hashlib.sha256(b).hexdigest()
def evaluar(d):
 if d['recepcion']=='FALLO':return 'FALLO_TECNICO'
 if d['recepcion']!='ADMITIDA':return 'NO_ADMITIDA'
 if d['perfil']!='FIJADO' or d['pertinencia']=='INCIERTA':return 'CONFIGURACION_PENDIENTE'
 if d['pertinencia']!='SI':return 'FUERA_DE_PERFIL'
 if d['conflicto']=='SI' or d['observacion']!='PRESENTE':return 'U'
 p=d['parametro'];v=d['valor'];target=d['objetivo']
 if p=='P11':
  if any(not re.fullmatch(r'0|[1-9][0-9]*',d[k]) for k in ['ancla','corte','valor']):return 'NO_ADMITIDA'
  a,c,t=map(int,[d['ancla'],d['corte'],v])
  if a>=c or t>c:return 'NO_ADMITIDA'
  return '1' if t>a else '0'
 if p=='P12':
  if d['tipo']!=d['tipo_objetivo']:return 'NO_ADMITIDA'
  return '1' if v==target else '0'
 if p=='P13':
  if not all(re.fullmatch('[0-9a-f]{64}',x) for x in [v,target]):return 'NO_ADMITIDA'
  return '1' if v==target else '0'
 if p=='P14':
  if v in ['TRANSICION','TRANSICION_Y_RETORNO']:return '1'
  if v in ['SIN_TRANSICION','MISMO_VALOR'] and d['cobertura']=='COMPLETA':return '0'
  return 'U'
 if p=='P15':return {'EXIGE':'1','NO_EXIGE':'0'}.get(v,'U')
 raise ValueError('Parámetro no contratado')

def admision(raw,expected,producer,authorized,scope,expected_scope):
 if h(raw)!=expected:return 'INTEGRIDAD'
 if producer not in authorized:return 'PRODUCTOR'
 if scope!=expected_scope:return 'AMBITO'
 return 'ADMISIBLE_DOCUMENTAL'
def object_unique(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('CLAVE_REPETIDA')
  d[k]=v
 return d
def cobertura(nodes,edges,start,observed,frontiers):
 if len(set(nodes))!=len(nodes):return 'IDENTIDAD_DUPLICADA'
 if start not in nodes:return 'ORIGEN_AUSENTE'
 visited=set();todo=[start]
 while todo:
  n=todo.pop()
  if n in visited:continue
  visited.add(n)
  for a,b in edges:
   if a!=n:continue
   if b not in nodes:
    if frontiers.get(b)!='ACREDITADA':return 'FRONTERA_SIN_EVIDENCIA'
   else:todo.append(b)
 if not visited<=set(observed):return 'INSTANCIA_NO_CUBIERTA'
 return 'COBERTURA_DEL_GRAFO_DECLARADO'
def balance(cmin,cmax,vmin,vmax,currency='EUR',vcurrency='EUR',nonmonetary=False):
 if currency!=vcurrency:return 'UNIDADES_INCOMPATIBLES'
 if nonmonetary:return 'JUICIO_NO_RESUELTO'
 try:
  if any(not re.fullmatch(r'(0|[1-9][0-9]*)(\.[0-9]+)?',x) for x in [cmin,cmax,vmin,vmax]):return 'DATO_NO_ADMITIDO'
  a,b,c,d=map(Decimal,[cmin,cmax,vmin,vmax])
 except (TypeError,InvalidOperation):return 'DATO_NO_ADMITIDO'
 if a>b or c>d:return 'INTERVALO_INVALIDO'
 if a>d:return 'EXCESO_ACREDITADO'
 if b<=c:return 'COMPARACION_NO_EXCEDE'
 return 'JUICIO_NO_RESUELTO'
def conclusion(required,evidence,admission=True,applicable=True,proven_exclusion=False,technical=False):
 if technical:return 'FALLO_TECNICO_SIN_PRODUCTO'
 if not admission:return 'NO_ADMITIDA_SIN_DICTAMEN'
 if not applicable:return 'EXCLUSION_FUNDADA' if proven_exclusion else 'INSUFICIENTE'
 if not required:return 'INSUFICIENTE'
 return 'SUFICIENTE_EN_ALCANCE_SINTETICO' if all(evidence.get(x)=='ACREDITADA' for x in required) else 'INSUFICIENTE'
def aplicabilidad(conditions):
 if not conditions:return 'NO_RESUELTA'
 if 'FALSA' in conditions:return 'NO_APLICABLE'
 if all(x=='CIERTA' for x in conditions):return 'APLICABLE'
 return 'NO_RESUELTA'
def ventana(start,end,at,duration,recovery,clock='EXACTO'):
 if clock!='EXACTO':return 'ORDEN_NO_RESUELTO'
 a,b,t,d,r=map(int,[start,end,at,duration,recovery])
 if a>=b or d<0 or r<0:return 'INTERVALO_INVALIDO'
 return 'CABE' if a<=t<b and t+d+r<=b else 'NO_CABE'
def permiso(action,asset,at,grant):
 if grant.get('origen')!='ORGANIZACION_ACREDITADA':return 'NO_ACREDITADO'
 if action not in grant['acciones'] or asset not in grant['activos']:return 'FUERA_DE_AMBITO'
 if not grant['desde']<=at<grant['hasta']:return 'NO_VIGENTE'
 return 'PERMISO_DOCUMENTADO'

def main():
 cases=json.loads((R/'TESTIGOS_PREVIOS.json').read_text());results=[]
 for c in cases:
  actual=evaluar(c['entrada']);results.append(dict(id=c['id'],expected=c['esperado'],actual=actual,pasa=actual==c['esperado']))
 assert all(x['pasa'] for x in results),[x for x in results if not x['pasa']]
 controls=[]
 def check(id,expected,actual,attack):
  controls.append(dict(id=id,expected=expected,actual=actual,ataque=attack,pasa=expected==actual));assert actual==expected,(id,expected,actual)
 raw=b'{"activo":"it-001","evento":"creacion"}';sha=h(raw)
 check('E01','ADMISIBLE_DOCUMENTAL',admision(raw,sha,'capturador-1',['capturador-1'],'it-001','it-001'),'Control completo')
 check('E02','INTEGRIDAD',admision(raw+b' ',sha,'capturador-1',['capturador-1'],'it-001','it-001'),'Un byte cambiado')
 check('E03','PRODUCTOR',admision(raw,sha,'suplantador',['capturador-1'],'it-001','it-001'),'Hash correcto con productor no autorizado')
 check('E04','AMBITO',admision(raw,sha,'capturador-1',['capturador-1'],'it-002','it-001'),'Productor admitido para otro activo')
 for id,text,expected in [('E05','{"valor":"7.50","valor":"0"}','CLAVE_REPETIDA'),('E06','{"valor":"7.50","id":"0001","ticks":"9007199254740993"}','EXACTO')]:
  try:
   obj=json.loads(text,object_pairs_hook=object_unique);v='EXACTO' if list(obj.values())==['7.50','0001','9007199254740993'] else 'OTRO'
  except ValueError as e:v=str(e)
  check(id,expected,v,'Claves únicas y originales exactos')
 check('E07','COBERTURA_DEL_GRAFO_DECLARADO',cobertura(['a','b'],[['a','b'],['b','a']],'a',['a','b'],{}),'Ciclo sin omisión ni bucle infinito')
 check('E08','INSTANCIA_NO_CUBIERTA',cobertura(['a','b'],[['a','b']],'a',['a'],{}),'Segunda instancia omitida')
 check('E09','FRONTERA_SIN_EVIDENCIA',cobertura(['a'],[['a','externa']],'a',['a'],{}),'Dependencia externa')
 check('E10','COBERTURA_DEL_GRAFO_DECLARADO',cobertura(['a'],[['a','externa']],'a',['a'],{'externa':'ACREDITADA'}),'Frontera explícita acreditada en testigo')
 check('E11','IDENTIDAD_DUPLICADA',cobertura(['a','a'],[],'a',['a'],{}),'Duplicado no infla cobertura')
 check('E12','ORIGEN_AUSENTE',cobertura([],[],'a',[],{}),'Lista vacía sin cobertura')
 for id,args,expected in [('E13',['7.50','7.50','10.00','10.00'],'COMPARACION_NO_EXCEDE'),('E14',['11','12','9','10'],'EXCESO_ACREDITADO'),('E15',['7','12','9','10'],'JUICIO_NO_RESUELTO'),('E16',['9007199254740993','9007199254740993','9007199254740992','9007199254740992'],'EXCESO_ACREDITADO'),('E17',['12','7','9','10'],'INTERVALO_INVALIDO'),('E18',['?','0','9','10'],'DATO_NO_ADMITIDO')]:check(id,expected,balance(*args),'Balance exacto y fronteras de incertidumbre')
 check('E19','UNIDADES_INCOMPATIBLES',balance('1','2','9','10','EUR','USD'),'No conversión inventada')
 check('E20','JUICIO_NO_RESUELTO',balance('1','2','9','10',nonmonetary=True),'Impacto no monetizado no es cero')
 obligations=['integridad','aplicabilidad','completitud','efecto','vigencia','cobertura','destinatario'];e={x:'ACREDITADA' for x in obligations}
 check('E21','SUFICIENTE_EN_ALCANCE_SINTETICO',conclusion(obligations,e),'Caso acotado completo; no ejecución SV')
 for i,key in enumerate(obligations,22):
  ee=e.copy();ee.pop(key);check(f'E{i:02}','INSUFICIENTE',conclusion(obligations,ee),'Omitir '+key)
 check('E29','FALLO_TECNICO_SIN_PRODUCTO',conclusion(obligations,e,technical=True),'Fallo no es salida alternativa')
 check('E30','NO_ADMITIDA_SIN_DICTAMEN',conclusion(obligations,e,admission=False),'No admisión no es U')
 check('E31','EXCLUSION_FUNDADA',conclusion(obligations,e,applicable=False,proven_exclusion=True),'Exclusión no afirma corrección')
 check('E32','INSUFICIENTE',conclusion(obligations,e,applicable=False),'Desconocimiento no es exclusión fundada')
 check('E33','INSUFICIENTE',conclusion([],{}),'Conjunción vacía no crea suficiencia')
 check('E34','APLICABLE',aplicabilidad(['CIERTA','CIERTA']),'Conjunción de condiciones admitidas')
 check('E35','NO_RESUELTA',aplicabilidad(['CIERTA','DESCONOCIDA']),'Condición desconocida no es falsa')
 check('E36','NO_APLICABLE',aplicabilidad(['CIERTA','FALSA']),'Refutación suficiente en conjunción explícita')
 check('E37','NO_RESUELTA',aplicabilidad([]),'Regla vacía no acredita pertinencia')
 check('E38','CABE',ventana('100','200','100','80','20'),'Duración y recuperación caben exactamente')
 check('E39','NO_CABE',ventana('100','200','200','0','0'),'Comenzar al fin excluido')
 check('E40','NO_CABE',ventana('100','200','110','80','20'),'Recuperación invade frontera')
 check('E41','ORDEN_NO_RESUELTO',ventana('100','200','110','80','0','INCIERTO'),'Orden no fiable no se redondea')
 check('E42','INTERVALO_INVALIDO',ventana('100','100','100','0','0'),'Intervalo vacío')
 grant=dict(origen='ORGANIZACION_ACREDITADA',acciones=['reiniciar'],activos=['a'],desde=100,hasta=200)
 check('E43','PERMISO_DOCUMENTADO',permiso('reiniciar','a',150,grant),'Permiso concreto en testigo sintético')
 check('E44','FUERA_DE_AMBITO',permiso('reiniciar','b',150,grant),'Permiso de otro activo')
 check('E45','NO_VIGENTE',permiso('reiniciar','a',200,grant),'Permiso caducado')
 check('E46','NO_ACREDITADO',permiso('reiniciar','a',150,grant|{'origen':'DIRECTOR_DEL_CATALOGO'}),'Dirección curricular no sustituye organización')
 check('E47','FUERA_DE_AMBITO',permiso('instalar','a',150,grant),'Acción no autorizada')
 check('E48','INSUFICIENTE',conclusion(['padre_terminado','hijo_terminado'],{'padre_terminado':'ACREDITADA'}),'Hijo no cubierto')
 check('E49','INSUFICIENTE',conclusion(['creacion','servicio_util'],{'creacion':'ACREDITADA'}),'Crear no inicializar')
 check('E50','INSUFICIENTE',conclusion(['correccion'],{'mitigacion':'ACREDITADA'}),'Mitigación no corrección')
 check('E51','INSUFICIENTE',conclusion(['comprobacion_vigente'],{'comprobacion_historica':'ACREDITADA'}),'Historia anterior sin vigencia')
 # Sensibilidad de un observador de igualdad: dos testigos con verdad externa fijada.
 sensory=[('imagen-v2','imagen-v2',True),('imagen-v1','imagen-v2',False)]
 observers={'correcto':lambda a,b:a==b,'siempre_positivo':lambda a,b:True,'siempre_negativo':lambda a,b:False,'ignora_objetivo':lambda a,b:a=='imagen-v2'}
 # Tercer testigo evita que memorizar v2 parezca comprobar el objetivo.
 sensory.append(('imagen-v3','imagen-v3',True))
 sensitivity={name:sum(fn(a,b)!=expected for a,b,expected in sensory) for name,fn in observers.items()}
 assert sensitivity['correcto']==0 and all(sensitivity[n]>0 for n in observers if n!='correcto')
 abl=[]
 for a in json.loads((R/'ABLACIONES_PREVIAS.json').read_text()):
  left=a['resto_declarado']|{a['parametro']:a['a']};right=a['resto_declarado']|{a['parametro']:a['b']}
  left.pop(a['parametro']);right.pop(a['parametro'])
  equal=left==right;distinct=a['oracle_a']!=a['oracle_b'];abl.append(dict(parametro=a['parametro'],proyecciones_iguales=equal,obligaciones_distintas=distinct,mutante_incapaz_de_distinguir=equal and distinct));assert equal and distinct
 report=dict(alcance='ENSAYO_DOCUMENTAL_SINTETICO_NO_SV',casos=results,controles=controls,sensibilidad=sensitivity,ablaciones=abl,entorno=dict(python=sys.version,platform=platform.platform()),oraculos_sha256=h((R/'TESTIGOS_PREVIOS.json').read_bytes()))
 out=json.dumps(report,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode();(R/'RESULTADOS.json').write_bytes(out+b'\n')
 print(json.dumps(dict(casos=len(results),controles=len(controls),sensibilidad=sensitivity,ablaciones=len(abl),fallos=0)))
if __name__=='__main__':main()
