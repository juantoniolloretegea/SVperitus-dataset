"""Proyección complementaria de un XLSX congelado. Sólo lectura, biblioteca estándar."""
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
import xml.etree.ElementTree as ET
import json,hashlib
R=Path(__file__).resolve().parent;ROOT=R.parent;O=ROOT/'outputs/cyb-universo-completo-20260909'
NS={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def projection(raw):
 with ZipFile(BytesIO(raw)) as z:
  wb=ET.fromstring(z.read('xl/workbook.xml'))
  rel={r.attrib['Id']:r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  strings=[''.join(t.itertext()) for t in ET.fromstring(z.read('xl/sharedStrings.xml'))] if 'xl/sharedStrings.xml'in z.namelist() else []
  sheets=[]
  for sh in wb.findall('x:sheets/x:sheet',NS):
   target=rel[sh.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']].lstrip('/')
   if not target.startswith('xl/'):target='xl/'+target
   cells=[]
   for c in ET.fromstring(z.read(target)).findall('.//x:sheetData/x:row/x:c',NS):
    typ=c.attrib.get('t','n');v=c.find('x:v',NS);value='' if v is None else v.text or ''
    if typ=='s':value=strings[int(value)];typ='texto'
    elif typ=='inlineStr':value=''.join(c.find('x:is',NS).itertext());typ='texto'
    elif typ=='str':typ='texto'
    f=c.find('x:f',NS);formula=None if f is None else f.text or ''
    if value=='' and formula is None:continue
    cells.append(dict(celda=c.attrib['r'],tipo=typ,valor=value,formula=formula))
   cells.sort(key=lambda c:(int(''.join(x for x in c['celda'] if x.isdigit())),column(c['celda'])))
   sheets.append(dict(nombre=sh.attrib['name'],celdas=cells))
  obj=dict(esquema='Proyección complementaria del contenido de celdas, versión 1',alcance='Orden de hojas, coordenadas, tipos, valores conservados y fórmulas. Excluye estilos, comentarios, dibujos, propiedades ZIP y fecha de guardado. No acredita recálculo en Excel ni aprobación humana.',hojas=sheets)
  return (json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()
def column(addr):
 v=0
 for x in addr:
  if x.isalpha():v=v*26+ord(x)-64
 return v
def main():
 p=O/'CATALOGO_CURRICULAR_CIBERSEGURIDAD_v0.8.xlsx';raw=p.read_bytes();before=hashlib.sha256(raw).hexdigest();a=projection(raw);b=projection(raw);assert a==b
 # Metadatos ZIP diferentes no cambian el contenido de la proyección.
 buf=BytesIO()
 with ZipFile(BytesIO(raw)) as source,ZipFile(buf,'w',ZIP_DEFLATED) as dest:
  for name in source.namelist():
   zi=ZipInfo(name,date_time=(2026,9,9,12,0,0));zi.compress_type=ZIP_DEFLATED;dest.writestr(zi,source.read(name))
 altered=buf.getvalue();assert hashlib.sha256(altered).hexdigest()!=before and projection(altered)==a
 # Una alteración real del texto de una celda sí debe detectarse.
 obj=json.loads(a);target=next(s for s in obj['hojas'] if s['nombre']=='67_Parametros')['celdas'];original=next(c for c in target if c['celda']=='B5');original['valor']+='-ALTERADO'
 mutated=(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode();assert mutated!=a
 (O/'PROYECCION_COMPLEMENTARIA_CATALOGO_v0.8.json').write_bytes(a)
 link=dict(libro=p.name,bytes=len(raw),sha256_libro=before,proyeccion='PROYECCION_COMPLEMENTARIA_CATALOGO_v0.8.json',sha256_proyeccion=hashlib.sha256(a).hexdigest(),regla='UTF-8; claves ordenadas; orden de hojas conservado; celdas por fila y columna; tipos, valores y fórmulas explícitos; sin edición del XLSX',naturaleza='Anexo complementario al Excel principal. Identidad documental, no firma personal ni aprobación del Director.',comprobaciones=dict(dos_lecturas_identicas=True,cambio_metadatos_zip_sin_cambio_proyeccion=True,alteracion_celda_detectada=True,libro_sin_modificacion=hashlib.sha256(p.read_bytes()).hexdigest()==before))
 (O/'VINCULACION_LIBRO_Y_PROYECCION_v0.8.json').write_text(json.dumps(link,ensure_ascii=False,indent=2)+'\n');print(json.dumps(link))
if __name__=='__main__':main()
