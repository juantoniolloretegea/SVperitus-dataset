# Anexo de verificación del primer universo

OP-CYB-001. Versión 0.2, de 9 de septiembre de 2026.

El catálogo principal es CATALOGO_CURRICULAR_CIBERSEGURIDAD_v0.8.xlsx.
La proyección textual y este anexo son complementarios. La huella del libro
identifica sus bytes exactos; la de la proyección identifica el contenido de
celdas descrito en su alcance. No constituyen una firma personal ni atribuyen
aprobación al Director.

La proyección se produjo mediante lectura del libro definitivo, sin abrirlo
para editarlo ni volverlo a guardar. Incluye orden de hojas, coordenadas,
tipos, valores conservados y fórmulas. Excluye estilos, comentarios, dibujos
y propiedades del contenedor. La modificación de metadatos de un contenedor
construido en memoria dejó idéntica la proyección; una modificación de
contenido de una celda se distinguió. El original no fue modificado.

Para comprobar la identidad y reproducir los ensayos, extraiga el anexo y ejecute:

```text
python verificar_anexo.py /ruta/CATALOGO_CURRICULAR_CIBERSEGURIDAD_v0.8.xlsx
```

El auxiliar utiliza exclusivamente la biblioteca estándar de Python, lee el
Excel y reproduce 64 registros sintéticos y siete modificaciones deliberadas
del observador en un directorio temporal. No es un compilador SV, no captura
datos de activos y no acredita eficacia de una corrección real. Los resultados
esperados están explícitos en los casos; la reproducción no constituye revisión
externa por pares.

Los registros paramétricos, las consecuencias, los veinte ámbitos, las ocho
clases de acción, los 36 candidatos adicionales resueltos, los catorce controles
y las 31 correspondencias conservan el razonamiento de constitución. La
estimación de 29 agrupaciones curriculares es una hipótesis de planificación:
sus escenarios no son universos constituidos ni intervalos estadísticos.

La bibliografía identifica autor, título, fecha o metadato de edición, enlace,
localizador, aportación, límites y, cuando se dispone del original, tamaño y
huella. Los archivos originales de terceros son materiales de investigación;
no se reproducen íntegramente en este anexo. Sus rutas describen el inventario
de adquisición, no archivos que se prometan dentro del ZIP.

La comprobación del Markdown empleó un analizador compatible con GitHub
Flavored Markdown y detectó las tablas que quedaban como párrafos. La
verificación conservada acredita estructura y ausencia de ese defecto; no es
una captura de pantalla de GitHub. Las ocho vistas de las hojas actuales del
Excel se revisaron durante la preparación del libro. Los valores y fórmulas
de 65 hojas históricas se conservaron; la portada identifica el registro actual.
