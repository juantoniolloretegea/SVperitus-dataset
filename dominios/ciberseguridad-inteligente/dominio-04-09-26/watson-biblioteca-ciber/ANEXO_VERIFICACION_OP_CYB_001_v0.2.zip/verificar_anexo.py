"""Comprueba el libro cerrado y reproduce los ensayos documentales del anexo.

Uso: python verificar_anexo.py /ruta/CATALOGO_CURRICULAR_CIBERSEGURIDAD_v0.8.xlsx
Sólo utiliza la biblioteca estándar de Python y no modifica el Excel.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

from proyeccion import projection


def main():
    root = Path(__file__).resolve().parent
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    book = Path(sys.argv[1]).resolve()
    link = json.loads((root / 'VINCULACION_LIBRO_Y_PROYECCION_v0.8.json').read_text())
    raw = book.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert len(raw) == link['bytes'], 'Tamaño del libro diferente'
    assert digest == link['sha256_libro'], 'El libro no es el archivo cerrado identificado'
    projected = projection(raw)
    assert projected == (root / link['proyeccion']).read_bytes(), 'Proyección diferente'
    assert hashlib.sha256(projected).hexdigest() == link['sha256_proyeccion']
    with tempfile.TemporaryDirectory(prefix='op-cyb-001-') as temporary:
        temp = Path(temporary)
        shutil.copy2(root / 'ensayos_documentales.py', temp)
        result = subprocess.run([sys.executable, str(temp / 'ensayos_documentales.py')],
                                check=True, capture_output=True, text=True)
        assert (temp / 'resultados_ensayos.json').read_bytes() == (root / 'resultados_ensayos.json').read_bytes(), 'Resultados no reproducidos'
        assert (temp / 'casos_previos.json').read_bytes() == (root / 'casos_previos.json').read_bytes(), 'Casos diferentes'
        trials = json.loads(result.stdout)
    assert hashlib.sha256(book.read_bytes()).hexdigest() == digest, 'El libro fue modificado'
    print(json.dumps({'libro_identico': True, 'proyeccion_identica': True,
                      'libro_sin_modificacion': True, 'ensayos_reproducidos': trials,
                      'alcance': 'Identidad documental y registros sintéticos; no validación de un sistema real.'},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
