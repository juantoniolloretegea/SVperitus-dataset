"""Contraste de registros sintéticos. No es un capturador ni un ejecutor SV."""
from pathlib import Path
import json,hashlib,copy
R=Path(__file__).resolve().parent
def evaluate(p,x):
 if x.get('fallo_lectura'):return 'FALLO_TECNICO'
 if x.get('admitida') is False:return 'NO_ADMITIDA'
 if x.get('conflicto'):return 'U'
 if p in ('P16','P21'):
  if x.get('ambito')!='persistente' and p=='P16':return 'NO_ADMITIDA'
  if p=='P21' and x.get('ausente'):return 'NO_APLICABLE'
  if x.get('valor') is None or x.get('objetivo') is None:return 'U'
  if type(x['valor'])!=type(x['objetivo']):return 'NO_ADMITIDA'
  return '1' if x['valor']==x['objetivo'] else '0'
 if p=='P17':
  return {'hito_acreditado':'1','fallo_inicializacion':'0','previo_al_hito':'0'}.get(x.get('estado'),'U')
 if p=='P18':
  if x.get('enabled') not in ('0','1'):return 'U'
  return x['enabled']
 if p=='P19':
  if not x.get('en_transicion'):return 'NO_APLICABLE'
  if x.get('estado') not in ('0','1') or x.get('objetivo') not in ('0','1'):return 'U'
  return '1' if x['estado']==x['objetivo'] else '0'
 if p=='P20':
  if x.get('referencia_utilizable') is True:return '1'
  if x.get('referencia_utilizable') is False and x.get('enumeracion_completa'):return '0'
  return 'U'
 if p=='P22':
  if not x.get('resolucion_completa'):return 'U'
  if x.get('seleccion') is None or x.get('objetivo') is None:return 'U'
  return '1' if x['seleccion']==x['objetivo'] else '0'
 if p=='P23':
  if x.get('operacion')!='FlushFileBuffers' or x.get('generacion_escritura')!=x.get('generacion_sincronizada'):return 'NO_ADMITIDA'
  return {'exito':'1','fallo':'0'}.get(x.get('resultado'),'U')
 if p=='P24':
  if x.get('pendiente') is True:return '1'
  if x.get('pendiente') is False and x.get('enumeracion_completa'):return '0'
  return 'U'
 raise ValueError(p)

# Resultados esperados establecidos mediante el contrato antes de ejecutar el auxiliar.
cases=[]
def c(p,label,x,want):cases.append(dict(id=f'ED-{len(cases)+1:03}',parametro=p,supuesto=label,entrada=x,esperado=want))
c('P16','Persistencia y utilización coinciden',dict(ambito='persistente',valor='seguro',objetivo='seguro'),'1')
c('P16','Valor persistente anterior',dict(ambito='persistente',valor='anterior',objetivo='seguro'),'0')
c('P16','Falta lectura persistente',dict(ambito='persistente',objetivo='seguro'),'U')
c('P16','Se ofrece lectura efectiva como persistente',dict(ambito='efectivo',valor='seguro',objetivo='seguro'),'NO_ADMITIDA')
c('P16','Cero numérico no es texto cero',dict(ambito='persistente',valor=0,objetivo='0'),'NO_ADMITIDA')
c('P16','Identificador con ceros iniciales',dict(ambito='persistente',valor='0001',objetivo='1'),'0')
c('P17','Inicialización terminada',dict(estado='hito_acreditado'),'1')
c('P17','Creación satisfactoria sin prueba de inicialización',dict(estado='creado'),'U')
c('P17','Fallo de inicialización después de creación',dict(estado='fallo_inicializacion'),'0')
c('P17','Estado previo al hito observado',dict(estado='previo_al_hito'),'0')
c('P18','Parche habilitado',dict(enabled='1'),'1')
c('P18','Parche deshabilitado',dict(enabled='0'),'0')
c('P18','Desaparición de archivo no demuestra deshabilitación',dict(),'U')
c('P19','Tarea objetivo durante aplicación',dict(en_transicion=True,estado='1',objetivo='1'),'1')
c('P19','Tarea antigua durante aplicación',dict(en_transicion=True,estado='0',objetivo='1'),'0')
c('P19','Objetivo de retirada alcanzado',dict(en_transicion=True,estado='0',objetivo='0'),'1')
c('P19','Fuera de transición: -1 no significa sin parche',dict(en_transicion=False,estado='-1',objetivo='1'),'NO_APLICABLE')
c('P19','-1 dentro de una transición declarada es inconsistencia',dict(en_transicion=True,estado='-1',objetivo='1'),'U')
c('P20','Referencia anterior conservada',dict(referencia_utilizable=True,enumeracion_completa=False),'1')
c('P20','Ausencia acreditada',dict(referencia_utilizable=False,enumeracion_completa=True),'0')
c('P20','Ausencia con enumeración parcial',dict(referencia_utilizable=False,enumeracion_completa=False),'U')
c('P21','Entrada objetivo',dict(valor='contenido-B',objetivo='contenido-B'),'1')
c('P21','Entrada anterior pese a origen nuevo',dict(valor='contenido-A',objetivo='contenido-B'),'0')
c('P21','Falta contenido observado',dict(objetivo='contenido-B'),'U')
c('P21','Ausencia legítima de entrada',dict(ausente=True,objetivo='contenido-B'),'NO_APLICABLE')
c('P22','Selección del objetivo',dict(resolucion_completa=True,seleccion='B',objetivo='B'),'1')
c('P22','Selección anterior aunque exista el objetivo',dict(resolucion_completa=True,seleccion='A',objetivo='B'),'0')
c('P22','Búsqueda con precedencia desconocida',dict(resolucion_completa=False,seleccion='B',objetivo='B'),'U')
c('P23','Sincronización satisfactoria de la escritura pertinente',dict(operacion='FlushFileBuffers',generacion_escritura='w2',generacion_sincronizada='w2',resultado='exito'),'1')
c('P23','Sincronización fallida es hecho observado',dict(operacion='FlushFileBuffers',generacion_escritura='w2',generacion_sincronizada='w2',resultado='fallo'),'0')
c('P23','Sin resultado',dict(operacion='FlushFileBuffers',generacion_escritura='w2',generacion_sincronizada='w2'),'U')
c('P23','Se ofrece FlushViewOfFile como equivalente',dict(operacion='FlushViewOfFile',generacion_escritura='w2',generacion_sincronizada='w2',resultado='exito'),'NO_ADMITIDA')
c('P23','Sincronización anterior a una nueva escritura',dict(operacion='FlushFileBuffers',generacion_escritura='w2',generacion_sincronizada='w1',resultado='exito'),'NO_ADMITIDA')
c('P24','Operación pendiente pese al éxito del instalador',dict(pendiente=True,enumeracion_completa=True),'1')
c('P24','Cola completa sin la operación',dict(pendiente=False,enumeracion_completa=True),'0')
c('P24','Cola parcial sin la operación',dict(pendiente=False,enumeracion_completa=False),'U')
c('P24','Cancelación: ausencia no acredita aplicación',dict(pendiente=False,enumeracion_completa=True,cancelada=True),'0')
for p in [f'P{i}' for i in range(16,25)]:
 c(p,'Fallo del lector, sin estado del dominio',dict(fallo_lectura=True),'FALLO_TECNICO')
 c(p,'Evidencia no admitida',dict(admitida=False),'NO_ADMITIDA')
 c(p,'Conflicto entre evidencias admitidas',dict(conflicto=True),'U')

def main():
 (R/'casos_previos.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
 result=[dict(x,obtenido=evaluate(x['parametro'],x['entrada'])) for x in cases]
 assert all(x['obtenido']==x['esperado'] for x in result)
 # Mutaciones del observador: se registran los casos concretos que las refutan.
 mutants={
 'Siempre favorable':lambda p,x:'1',
 'Ausencia convertida en cero':lambda p,x:'0' if evaluate(p,x)=='U' else evaluate(p,x),
 'Fallo técnico convertido en incertidumbre':lambda p,x:'U' if x.get('fallo_lectura') else evaluate(p,x),
 'Estado de tarea sin contexto':lambda p,x: ('0' if x.get('estado')=='-1' else x.get('estado','U')) if p=='P19' else evaluate(p,x),
 'Sincronización sin comprobar generación':lambda p,x:'1' if p=='P23' and x.get('resultado')=='exito' else evaluate(p,x),
 'Ausencia de referencia sin cobertura':lambda p,x:'0' if p=='P20' and x.get('referencia_utilizable') is False else evaluate(p,x),
 'Ceros iniciales eliminados':lambda p,x:('1' if int(x['valor'])==int(x['objetivo']) else '0') if p=='P16' and x.get('valor')=='0001' else evaluate(p,x),
 }
 mutation=[]
 for name,f in mutants.items():
  caught=[x['id'] for x in cases if f(x['parametro'],x['entrada'])!=x['esperado']]
  assert caught;mutation.append(dict(mutacion=name,casos_refutadores=caught))
 payload=dict(alcance='Contratos sobre registros sintéticos; sin observación de activos ni ejecución SV',casos=result,mutaciones=mutation)
 raw=(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()
 (R/'resultados_ensayos.json').write_bytes(raw)
 print(json.dumps(dict(casos=len(result),discordancias=0,mutaciones_detectadas=len(mutation),sha256=hashlib.sha256(raw).hexdigest())))
if __name__=='__main__':main()
