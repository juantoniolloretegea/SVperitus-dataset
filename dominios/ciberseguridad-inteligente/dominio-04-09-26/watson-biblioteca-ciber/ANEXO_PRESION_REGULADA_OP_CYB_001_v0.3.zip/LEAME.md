# Anexo complementario de presión regulada

OP-CYB-001, revisión documental v0.3, 9 de septiembre de 2026.

El principal es CATALOGO_CURRICULAR_CIBERSEGURIDAD_v0.9.xlsx. Su huella identifica los bytes entregados. La proyección de celdas se obtiene del libro cerrado y tiene un alcance menor que el archivo: no incluye estilo, comentarios o metadatos del contenedor. No se ha vuelto a guardar el libro para generarla. Ninguna huella autentica a un autor ni acredita aprobación humana.

Para reproducir las comprobaciones, extraiga el anexo y ejecute:

```text
python verificar_anexo.py /ruta/CATALOGO_CURRICULAR_CIBERSEGURIDAD_v0.9.xlsx
```

El auxiliar usa la biblioteca estándar, lee el Excel y repite en un directorio temporal 46 casos sintéticos, once mutaciones del observador y diez pares documentales. No es un compilador SV ni ejecuta autenticación, criptografía o un sistema real. Las expectativas están fijadas en testigos.json; resultados.json conserva la ejecución comprobada.

parametros_completos.json reúne las 32 definiciones para inspección auxiliar; el catálogo principal sigue siendo Excel, con P01–P24 en 67/68 y P25–P32 en 74. Los JSON son registros y anexos técnicos, no un catálogo CSV sustitutivo. Los inventarios de fuentes describen copias de investigación y fallos de acceso; esas rutas no prometen archivos originales dentro del ZIP. No se republican los PDF completos de terceros.

La lectura del Lenguaje es estática y se identifica en identidad_lenguaje.json. El resultado de los pares demuestra pérdida en una reducción documental a estados técnicos; no demuestra una pérdida de toda la IR. Las capacidades materiales pendientes y los destinatarios responsables constan en requisitos_lenguaje.json.

Las particiones y presupuestos del dominio son hipótesis. El desglose evita el doble cómputo de ocho definiciones, pero esa imputación sigue siendo una hipótesis contable. La decisión de uno o dos universos corresponde al Director, fundada en el contraste semántico.
