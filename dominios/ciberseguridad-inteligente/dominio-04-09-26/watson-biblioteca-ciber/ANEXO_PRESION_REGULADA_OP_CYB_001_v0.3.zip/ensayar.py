"""Observador documental externo. No es compilador, capturador ni ejecución SV."""
from pathlib import Path
import json,re,hashlib,copy
R=Path(__file__).resolve().parent
def interval(x):
    if not isinstance(x,list) or len(x)!=2:raise ValueError('intervalo')
    if any(not isinstance(n,str) or not re.fullmatch(r'0|-[1-9][0-9]*|[1-9][0-9]*',n) for n in x):raise ValueError('entero canónico')
    a,b=map(int,x)
    if a>b:raise ValueError('orden')
    return a,b
def judge(p,d,mutant=None):
    try:
        for flag in ['admitted','applicable','complete','prior','conflict']:
            if flag in d and type(d[flag]) is not bool:raise ValueError('tipo lógico')
        if d.get('admitted') is False:return 'NO_ADMISION'
        if d.get('applicable') is False:return '1' if mutant=='APLICABILIDAD_COMO_EXITO' else 'NO_APLICABLE'
        if d.get('conflict'):return 'U'
        if p=='P25':
            if mutant=='CUENTA_COMO_SESION' and d.get('account'):return '1'
            if 'linked' not in d:return 'U'
            return '1' if d['session']==d['linked'] else '0'
        if p=='P26':
            if mutant=='FIRMA_COMO_COMPETENCIA':return '1'
            if [d['issuer'],d['power']] in d['grants']:return '1'
            return '0' if d.get('complete') else 'U'
        if p=='P27':
            if 'scope' not in d:return 'U'
            if not isinstance(d['scope'],list) or not isinstance(d['act'],list):raise ValueError('alcance')
            if len(d['act'])!=4 or any(not isinstance(v,str) for v in d['act']):raise ValueError('tupla')
            if any(not isinstance(t,list) or len(t)!=4 or any(not isinstance(v,str) for v in t) for t in d['scope']):raise ValueError('tupla de alcance')
            if mutant=='SOLO_NOMBRE_ACCION':return '1' if any(x[0]==d['act'][0] for x in d['scope']) else '0'
            return '1' if d['act'] in d['scope'] else '0'
        if p=='P28':
            if any(k not in d for k in ['window','start','end']):return 'U'
            lo,hi=interval(d['window']);sl,su=interval(d['start']);el,eu=interval(d['end'])
            if su>el:raise ValueError('inicio/fin')
            if mutant=='DOBLE_PRECISION_INTERMEDIA':lo,hi,sl,su,el,eu=map(float,[lo,hi,sl,su,el,eu])
            if mutant=='IGNORAR_INCERTIDUMBRE':sl=su=(sl+su)//2;el=eu=(el+eu)//2
            if sl>=lo and eu<=hi:return '1'
            if su<lo or el>hi:return '0'
            return 'U'
        if p=='P29':
            el,eu=interval(d['end']);rr=[interval(x) for x in d['revocations']]
            if mutant=='CUALQUIER_REVOCACION' and rr:return '1'
            if any(ru<=el for rl,ru in rr):return '1'
            if d.get('complete') and all(rl>eu for rl,ru in rr):return '0'
            if mutant=='SILENCIO_COMO_AUSENCIA' and not rr:return '0'
            return 'U'
        if p=='P30':
            il,iu=interval(d['issued']);sl,su=interval(d['start'])
            if mutant=='FECHA_ESCRITA_COMO_EMISION' and 'written_date' in d:il=iu=int(d['written_date'])
            if iu<sl:return '1'
            if il>=su:return '0'
            return 'U'
        if p=='P31':
            if mutant=='CUENTAS_COMO_PERSONAS' and 'account_a' in d:return '1' if d['account_a']!=d['account_b'] else '0'
            if not all(k in d for k in ['principal_a','principal_b']):return 'U'
            return '1' if d['principal_a']!=d['principal_b'] else '0'
        if p=='P32':
            if d.get('prior') is False:return 'NO_ADMISION'
            if mutant=='PERMISO_COMO_PLAN' and d.get('emergency_permit'):return '1'
            if d['act'] in d['plan']:return '1'
            return '0' if d.get('complete') else 'U'
        raise ValueError('parámetro')
    except (ValueError,KeyError,TypeError):return 'FALLO_TECNICO'
def main():
    cases=json.loads((R/'testigos.json').read_text())
    result=[]
    for c in cases:
        got=judge(c['parametro'],c['entrada'])
        result.append({**c,'obtenido':got,'concordante':got==c['esperado']})
    assert all(c['concordante'] for c in result),[c['id'] for c in result if not c['concordante']]
    mutations=[]
    for m in ['CUENTA_COMO_SESION','FIRMA_COMO_COMPETENCIA','SOLO_NOMBRE_ACCION','IGNORAR_INCERTIDUMBRE','CUALQUIER_REVOCACION','SILENCIO_COMO_AUSENCIA','FECHA_ESCRITA_COMO_EMISION','CUENTAS_COMO_PERSONAS','PERMISO_COMO_PLAN','APLICABILIDAD_COMO_EXITO','DOBLE_PRECISION_INTERMEDIA']:
        ids=[c['id'] for c in cases if judge(c['parametro'],c['entrada'],m)!=c['esperado']]
        assert ids,m
        mutations.append(dict(mutacion=m,casos_refutadores=ids))
    pairs=json.loads((R/'pares_semanticos.json').read_text());contrast=[]
    for pair in pairs:
        a,b=pair['a'],pair['b']
        assert a['technical']==b['technical'] and a!=b
        diffs=[k for k in a if a[k]!=b[k]]
        assert diffs==[pair['diferencia']]
        enc=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
        contrast.append(dict(id=pair['id'],proyeccion_tecnica_igual=enc(a['technical'])==enc(b['technical']),expedientes_diferentes=enc(a)!=enc(b),campo_distinto=diffs[0],requisito=pair['requisito'],estatuto='Pérdida en reducción documental propia; no ensayo de IR SV'))
    out=dict(casos=result,mutaciones=mutations,pares=contrast,alcance='Ensayos documentales sintéticos; no autenticación criptográfica ni SV productivo.',rust_ejecutado=False)
    raw=json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n'
    (R/'resultados.json').write_bytes(raw)
    print(json.dumps(dict(casos=len(result),discordancias=0,mutaciones=len(mutations),pares=len(contrast),sha256=hashlib.sha256(raw).hexdigest())))
if __name__=='__main__':main()
