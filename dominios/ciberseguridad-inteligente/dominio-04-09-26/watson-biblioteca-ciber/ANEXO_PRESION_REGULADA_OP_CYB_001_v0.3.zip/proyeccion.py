"""Proyección complementaria de un XLSX congelado. Sólo lectura, biblioteca estándar."""
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from io import BytesIO
import xml.etree.ElementTree as ET
import json,hashlib
NS={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def projection(raw):
 with ZipFile(BytesIO(raw)) as z:
  wb=ET.fromstring(z.read('xl/workbook.xml'))
  rel={r.attrib['Id']:r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  strings=[''.join(t.itertext()) for t in ET.fromstring(z.read('xl/sharedStrings.xml'))] if 'xl/sharedStrings.xml'in z.namelist() else []
  sheets=[]
  for sh in wb.findall('x:sheets/x:sheet',NS):
   target=rel[sh.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']].lstrip('/')
   if not target.startswith('xl/'):target='xl/'+target
   cells=[]
   for c in ET.fromstring(z.read(target)).findall('.//x:sheetData/x:row/x:c',NS):
    typ=c.attrib.get('t','n');v=c.find('x:v',NS);value='' if v is None else v.text or ''
    if typ=='s':value=strings[int(value)];typ='texto'
    elif typ=='inlineStr':value=''.join(c.find('x:is',NS).itertext());typ='texto'
    elif typ=='str':typ='texto'
    f=c.find('x:f',NS);formula=None if f is None else f.text or ''
    if value=='' and formula is None:continue
    cells.append(dict(celda=c.attrib['r'],tipo=typ,valor=value,formula=formula))
   cells.sort(key=lambda c:(int(''.join(x for x in c['celda'] if x.isdigit())),column(c['celda'])))
   sheets.append(dict(nombre=sh.attrib['name'],celdas=cells))
  obj=dict(esquema='Proyección complementaria del contenido de celdas, versión 1',alcance='Orden de hojas, coordenadas, tipos, valores conservados y fórmulas. Excluye estilos, comentarios, dibujos, propiedades ZIP y fecha de guardado. No acredita recálculo en Excel ni aprobación humana.',hojas=sheets)
  return (json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode()
def column(addr):
 v=0
 for x in addr:
  if x.isalpha():v=v*26+ord(x)-64
 return v
