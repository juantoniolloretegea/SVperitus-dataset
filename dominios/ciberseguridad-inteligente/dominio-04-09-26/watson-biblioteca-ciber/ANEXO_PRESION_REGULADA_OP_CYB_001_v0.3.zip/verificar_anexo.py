"""Comprobación documental externa de un libro ya cerrado. Sólo lectura del XLSX."""
from pathlib import Path
import hashlib,json,sys,tempfile,shutil,subprocess
from proyeccion import projection
R=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    if len(sys.argv)!=2:raise SystemExit('Uso: python verificar_anexo.py /ruta/CATALOGO_CURRICULAR_CIBERSEGURIDAD_v0.9.xlsx')
    p=Path(sys.argv[1]);link=json.loads((R/'VINCULACION_LIBRO_Y_PROYECCION_v0.9.json').read_text())
    original=p.read_bytes();before=digest(p)
    assert before==link['sha256_libro'] and len(original)==link['bytes'],'Identidad del libro'
    a,b=projection(original),projection(original)
    assert a==b and hashlib.sha256(a).hexdigest()==link['sha256_proyeccion'],'Proyección'
    assert a==(R/link['proyeccion']).read_bytes(),'Proyección publicada'
    expected=(R/'resultados.json').read_bytes()
    with tempfile.TemporaryDirectory(prefix='cyb-presion-verificar-') as temp:
        temp=Path(temp)
        for name in ['ensayar.py','testigos.json','pares_semanticos.json']:shutil.copy2(R/name,temp/name)
        run=subprocess.run([sys.executable,str(temp/'ensayar.py')],check=True,capture_output=True,text=True)
        assert (temp/'resultados.json').read_bytes()==expected,'Reproducción de resultados'
    assert digest(p)==before,'El libro no se modifica'
    result=json.loads(expected)
    print(json.dumps(dict(identidad_libro=True,proyeccion_identica=True,resultados_reproducidos=True,libro_sin_modificacion=True,casos=len(result['casos']),mutantes=len(result['mutaciones']),pares=len(result['pares']),alcance='Documental; no ejecución SV, autenticación material ni certificación'),ensure_ascii=False))
if __name__=='__main__':main()
